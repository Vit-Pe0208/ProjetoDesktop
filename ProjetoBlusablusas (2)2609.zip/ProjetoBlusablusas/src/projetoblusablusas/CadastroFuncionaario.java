/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import com.jtattoo.plaf.aluminium.AluminiumLookAndFeel;
import com.jtattoo.plaf.graphite.GraphiteLookAndFeel;
import com.jtattoo.plaf.luna.LunaLookAndFeel;
import com.jtattoo.plaf.smart.SmartLookAndFeel;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;



public class CadastroFuncionaario extends javax.swing.JInternalFrame {

   String situacao;
   String genero;
  
   
    public CadastroFuncionaario() {
        initComponents();
        designerInicial();
        atualizartabelaAdministrador();
        this.codigopessoa.setEnabled(false);
       
     
        
        
        
        
        
      
    }
    
    public void designerInicial(){
         this.TabelaAdministrador.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.TabelaAdministrador.getTableHeader().setOpaque(false);
        this.TabelaAdministrador.getTableHeader().setBackground(new Color(102,0,102));
        this.TabelaAdministrador.getTableHeader().setForeground(Color.WHITE);
        this.TabelaAdministrador.setRowHeight(25);
    }
    
       public void atualizartabelaAdministrador(){
         try {
            SimpleDateFormat dataAniversario = new SimpleDateFormat("dd/MM/yyyy");
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT \n" +
"p.nome AS Administrador,\n" +
" p.email AS EmailPessoal,\n" +
" p.cpf AS CPF,\n" +
" p.genero AS Gênero,\n" +
" p.data_nascimento AS DataNascimento,\n" +
" adm.matricula AS Matrícula,\n" +
" adm.cargo AS Cargo,\n" +
" p.situacao AS SituaçãoADM,p.id_pessoa\n" +
" FROM administrador adm\n" +
"INNER JOIN pessoa p ON p.id_pessoa=adm.id_pessoa;";
             
             
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaadm = (DefaultTableModel) this.TabelaAdministrador.getModel();
            tabelaadm.setNumRows(0);
             while(rs.next()){
                 Date dataDate = rs.getDate("DataNascimento");
                 String dataTexto=dataAniversario.format(dataDate);
                 
                 Object[] array ={rs.getString("Administrador"),rs.getString("EmailPessoal")
                 ,rs.getString("CPF"),rs.getString("Gênero"),dataTexto,
                 rs.getString("Matrícula"),rs.getString("Cargo"),rs.getString("SituaçãoADM"),rs.getString("id_pessoa")};
                 tabelaadm.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }
       

  
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        situacaoGrupo = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaAdministrador = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rAtivo = new javax.swing.JRadioButton();
        rInativo = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        matricula = new javax.swing.JTextField();
        nome = new javax.swing.JTextField();
        emailPessoa = new javax.swing.JTextField();
        cargo = new javax.swing.JTextField();
        cpf = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        codigopessoa = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        Feminino = new javax.swing.JRadioButton();
        Masculino = new javax.swing.JRadioButton();
        outro = new javax.swing.JRadioButton();
        calendariodataNascimento = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        salario = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        pesquisarFuncionario = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastro de Administradores");

        jPanel1.setBackground(new java.awt.Color(102, 0, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cadastros de Administradores");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1846, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        TabelaAdministrador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Administrador", "Emai lPessoal", "CPF", "Gênero", "DataNascimento", "Matrícula ADM", "Cargo", "SituaçãoADM", "Código Pessoa"
            }
        ));
        TabelaAdministrador.setSelectionBackground(new java.awt.Color(153, 0, 153));
        TabelaAdministrador.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TabelaAdministrador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelaAdministradorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaAdministrador);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Nome/sobrenome: ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Email Pessoal");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Situação :");

        situacaoGrupo.add(rAtivo);
        rAtivo.setText("Ativo");
        rAtivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rAtivoActionPerformed(evt);
            }
        });

        situacaoGrupo.add(rInativo);
        rInativo.setText("Inativo");
        rInativo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rInativoActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Salvar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Editar");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("Excluir");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Cargo");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Matrícula :");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Data de Nascimento");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Gênero :");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("CPF");

        matricula.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        nome.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        emailPessoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        cargo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        cpf.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Tabela de Cadastro de Funcionários");

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setText("Salários");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Código :");

        codigopessoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton6.setText("Limpar Campos");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        buttonGroup1.add(Feminino);
        Feminino.setText("Feminino");
        Feminino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FemininoActionPerformed(evt);
            }
        });

        buttonGroup1.add(Masculino);
        Masculino.setText("Masculino");
        Masculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MasculinoActionPerformed(evt);
            }
        });

        buttonGroup1.add(outro);
        outro.setText("Outro");
        outro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                outroActionPerformed(evt);
            }
        });

        calendariodataNascimento.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        calendariodataNascimento.setForeground(new java.awt.Color(255, 255, 255));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("Salário");

        salario.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Pesquisar Matrícula : ");

        pesquisarFuncionario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarFuncionarioKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel5)
                                .addComponent(jLabel8)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel11)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel14))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(35, 35, 35)
                                            .addComponent(cpf))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(27, 27, 27)
                                            .addComponent(codigopessoa, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(salario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                                                .addComponent(emailPessoa, javax.swing.GroupLayout.Alignment.TRAILING)))))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel7)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel10))
                                    .addGap(27, 27, 27)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(calendariodataNascimento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(Feminino)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(Masculino)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(outro))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jButton1)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jButton2)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jButton3)))
                                            .addGap(0, 0, Short.MAX_VALUE))))
                                .addComponent(jLabel6)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(117, 117, 117)
                                    .addComponent(rAtivo)
                                    .addGap(41, 41, 41)
                                    .addComponent(rInativo))
                                .addComponent(cargo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(matricula, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(jButton6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1218, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pesquisarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(66, 66, 66))
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(553, 553, 553)
                        .addComponent(jButton6))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(emailPessoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(salario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(calendariodataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel11)
                                    .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(33, 33, 33)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(Feminino)
                                        .addComponent(Masculino)
                                        .addComponent(outro))
                                    .addComponent(jLabel10))
                                .addGap(47, 47, 47)
                                .addComponent(jLabel9)))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(cargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(matricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(28, 28, 28)
                                .addComponent(jLabel3))
                            .addComponent(codigopessoa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(rAtivo)
                            .addComponent(rInativo))
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(pesquisarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
             SimpleDateFormat data= new SimpleDateFormat("yyyy-MM-dd");
             String dataformatada = data.format(this.calendariodataNascimento.getDate());
                 
           if(!RegexValidarFuncionario.validarNome(nome.getText())){
                JOptionPane.showMessageDialog(null, "Nome errado\nescreva apenas letras e comece com maiúsculas!");
                
            }else if(!RegexValidarFuncionario.validarCPF(cpf.getText())){
                JOptionPane.showMessageDialog(null, "CPF errado!\n[xxxxxxxxx-xx]");
            }else if(!RegexValidarFuncionario.validarMatricula(matricula.getText())){
                JOptionPane.showMessageDialog(null, "Matrícula errada errado\n[Duas letras máximo 16 caracteres]!");
                
            }else if(!RegexValidarFuncionario.validarCargo(cargo.getText())){
                 JOptionPane.showMessageDialog(null, "Cargo errado!\n[Digite apenas letras e comece com maiusculas]");
            }else if(!RegexValidarFuncionario.validarSalario(salario.getText())){
                JOptionPane.showMessageDialog(null, "Salário errado, digite apenas números\n![xxxxx.xx]");
            }else if(!RegexValidarFuncionario.validarEmail(this.emailPessoa.getText())){
                JOptionPane.showMessageDialog(null, "Email e errado!\n[usuario@blusablusas.com]"); 
            }else{
         Connection coin = conexaoBancoDeDados.conexaoBanco();
         String sql = "INSERT INTO pessoa(nome,email,cpf,genero,data_nascimento)\n" +
         "VALUES(?,?,?,?,?);";
         PreparedStatement stmt = coin.prepareStatement(sql);
         stmt.setString(1, this.nome.getText());
         stmt.setString(2, this.emailPessoa.getText());
         stmt.setString(3, this.cpf.getText());
         stmt.setString(4, this.genero);
         stmt.setString(5,  dataformatada);
         stmt.execute();
            
         sql= "INSERT INTO administrador(matricula,cargo,salario,id_pessoa)\n" +
        "VALUES(?,?,?,(SELECT id_pessoa FROM pessoa ORDER BY id_pessoa DESC LIMIT 1));";
         stmt= coin.prepareStatement(sql);
         stmt.setString(1, this.matricula.getText());
         stmt.setString(2, this.cargo.getText());
         stmt.setString(3, this.salario.getText());
         stmt.execute();
         
         sql="INSERT INTO login(usuario,senha,alterar_senha,id_pessoa)\n"
          + "VALUES((SELECT email FROM pessoa ORDER BY id_pessoa DESC LIMIT 1),UPPER(MD5('blusa123')),'S',(SELECT id_pessoa FROM pessoa ORDER BY id_pessoa DESC LIMIT 1));";
         stmt = coin.prepareStatement(sql);
         stmt.execute();
         
         
         stmt.close();
         coin.close();
         JOptionPane.showMessageDialog(null, "Funcionário Cadastrado com Sucesso!!");
         atualizartabelaAdministrador();          
        }   
        } catch (SQLException ex) {
            System.getLogger(CadastroFuncionaario.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
          
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TabelaAdministradorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelaAdministradorMouseClicked
        String data;
        this.salario.setEnabled(false);
        this.nome.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 0).toString());
        this.emailPessoa.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 1).toString());
        this.cpf.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 2).toString());
        this.genero=(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 3).toString());
        
        if(genero.equals("feminino")){
            this.Feminino.setSelected(true);
         }else if(genero.equals("masculino")){
             this.Masculino.setSelected(true);
         }else if(genero.equals("outro")){
             this.outro.setSelected(true);
         }
        data=this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 4).toString();
        this.matricula.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 5).toString());
        this.cargo.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 6).toString());
        situacao=this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 7).toString();
        
        if(situacao.equals("ativo")){
            this.rAtivo.setSelected(true);
        }else if(situacao.equals("inativo")){
            this.rInativo.setSelected(true);
        }
        this.codigopessoa.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 8).toString());
         SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
         
       try {
           Date datanasceu = date.parse(data);
           this.calendariodataNascimento.setDate(datanasceu);
       
       } catch (ParseException ex) {
           System.getLogger(CadastroFuncionario.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
    }//GEN-LAST:event_TabelaAdministradorMouseClicked

    private void rAtivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rAtivoActionPerformed
       situacao = "ativo";
    }//GEN-LAST:event_rAtivoActionPerformed

    private void rInativoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rInativoActionPerformed
        situacao ="inativo";
    }//GEN-LAST:event_rInativoActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
       try {
        SimpleDateFormat data= new SimpleDateFormat("yyyy-MM-dd");
        String dataformatada = data.format(this.calendariodataNascimento.getDate());
        
        if(!RegexValidarFuncionario.validarNome(nome.getText())){
                JOptionPane.showMessageDialog(null, "Nome errado\nescreva apenas letras e comece com maiúsculas!");
                
            }else if(!RegexValidarFuncionario.validarCPF(cpf.getText())){
                JOptionPane.showMessageDialog(null, "CPF errado!\n[xxxxxxxxx-xx]");
            }else if(!RegexValidarFuncionario.validarMatricula(matricula.getText())){
                JOptionPane.showMessageDialog(null, "Matrícula errada errado\n[Duas letras máximo 16 caracteres]!");
                
            }else if(!RegexValidarFuncionario.validarCargo(cargo.getText())){
                 JOptionPane.showMessageDialog(null, "Cargo errado!\n[Digite apenas letras e comece com maiusculas]");
            }else if(!RegexValidarFuncionario.validarEmail(this.emailPessoa.getText())){
                JOptionPane.showMessageDialog(null, "Email e errado!\n[usuario@blusablusas.com]"); 
            }else{
         Connection coin = conexaoBancoDeDados.conexaoBanco();
         String sql = "UPDATE pessoa SET nome = ?,email=?,cpf=?,genero=?,data_nascimento=?,situacao=? WHERE id_pessoa=?;";
         PreparedStatement stmt = coin.prepareStatement(sql);
         stmt.setString(1, this.nome.getText());
         stmt.setString(2, this.emailPessoa.getText());
         stmt.setString(3, this.cpf.getText());
         stmt.setString(4, this.genero);
         stmt.setString(5, dataformatada);
         stmt.setString(6, this.situacao);
         stmt.setString(7, this.codigopessoa.getText());
         stmt.executeUpdate();
         sql = "UPDATE administrador SET matricula=?,cargo=? WHERE id_pessoa=?;";
         stmt= coin.prepareStatement(sql);
         stmt.setString(1, this.matricula.getText());
         stmt.setString(2, this.cargo.getText());
         stmt.setString(3, this.codigopessoa.getText());
         stmt.executeUpdate();
         stmt.close();
         coin.close();
         JOptionPane.showMessageDialog(null, "Funcionário alterado com sucesso");
         atualizartabelaAdministrador();
         limparCampos();   
            }   
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionaario.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       } 
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        MovimentacaoCaixa caixa = new   MovimentacaoCaixa(null,true);
        caixa.setVisible(true);
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       limparCampos();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
      int resposta = JOptionPane.showConfirmDialog(null,
        "Tem certeza que deseja excluir este funcionário?\nEssa ação também removerá os dados pessoais.",
       "Confirmar Exclusão",
      JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        
        if(resposta== JOptionPane.YES_NO_OPTION){
             try {
           Connection coin = conexaoBancoDeDados.conexaoBanco();
           
           String sql = "DELETE FROM login WHERE id_pessoa=?;";
           PreparedStatement stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.codigopessoa.getText());
           stmt.execute();
           sql = "DELETE FROM administrador WHERE id_pessoa = ?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigopessoa.getText());
           stmt.execute();
           sql = "DELETE FROM pessoa WHERE id_pessoa=?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigopessoa.getText());
        
          
               stmt.execute();
               JOptionPane.showMessageDialog(null, "Funcionário Deletado");
               stmt.close();
               coin.close();
               atualizartabelaAdministrador();
               
               
          
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionaario.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
           
       }
            
        }
      
    }//GEN-LAST:event_jButton3MouseClicked

    private void FemininoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FemininoActionPerformed
        genero = "feminino";
    }//GEN-LAST:event_FemininoActionPerformed

    private void MasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MasculinoActionPerformed
        genero = "masculino";
    }//GEN-LAST:event_MasculinoActionPerformed

    private void outroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_outroActionPerformed
       genero = "outro";
    }//GEN-LAST:event_outroActionPerformed

    private void pesquisarFuncionarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarFuncionarioKeyPressed
      try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT \n" +
"p.nome AS Administrador,\n" +
" p.email AS EmailPessoal,\n" +
" p.cpf AS CPF,\n" +
" p.genero AS Gênero,\n" +
" p.data_nascimento AS DataNascimento,\n" +
" adm.matricula AS Matrícula,\n" +
" adm.cargo AS Cargo,\n" +
" p.situacao AS SituaçãoADM,p.id_pessoa\n" +
" FROM administrador adm\n" +
"INNER JOIN pessoa p ON p.id_pessoa=adm.id_pessoa WHERE adm.matricula LIKE '%"+this.pesquisarFuncionario.getText()+"%';";
             
                 
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaadm = (DefaultTableModel) this.TabelaAdministrador.getModel();
            tabelaadm.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Administrador"),rs.getString("EmailPessoal")
                 ,rs.getString("CPF"),rs.getString("Gênero"),rs.getString("DataNascimento"),
                 rs.getString("Matrícula"),rs.getString("Cargo"),rs.getString("SituaçãoADM"),rs.getString("id_pessoa")};
                 tabelaadm.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
        
        
    }//GEN-LAST:event_pesquisarFuncionarioKeyPressed
public void limparCampos(){
    this.nome.setText(null);
    this.cpf.setText(null);
    this.emailPessoa.setText(null);
    this.calendariodataNascimento.setDate(null);
    this.matricula.setText(null);
    this.cargo.setText(null);
    this.codigopessoa.setText(null);
    situacaoGrupo.clearSelection();
    buttonGroup1.clearSelection();
    this.salario.setText(null);
    this.salario.setEnabled(true);
    
    
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Feminino;
    private javax.swing.JRadioButton Masculino;
    private javax.swing.JTable TabelaAdministrador;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private com.toedter.calendar.JDateChooser calendariodataNascimento;
    private javax.swing.JTextField cargo;
    private javax.swing.JTextField codigopessoa;
    private javax.swing.JTextField cpf;
    private javax.swing.JTextField emailPessoa;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField matricula;
    private javax.swing.JTextField nome;
    private javax.swing.JRadioButton outro;
    private javax.swing.JTextField pesquisarFuncionario;
    private javax.swing.JRadioButton rAtivo;
    private javax.swing.JRadioButton rInativo;
    private javax.swing.JTextField salario;
    private javax.swing.ButtonGroup situacaoGrupo;
    // End of variables declaration//GEN-END:variables
}
