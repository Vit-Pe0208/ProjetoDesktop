/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetoblusablusas;

/**
 *
 * @author Vitor55679526
 */
public class RegexValidarProduto {
    
    public static boolean ValidarProduto(String produto){
        return  produto.matches("^[A-Za-zÀ-ÖØ-öø-ÿ0-9\\s\\-\\/&]{1,50}$");
    }
    public static boolean ValidarEstoque(String estoque){
        return estoque.matches("^[1-9][0-9]{0,5}$");
    }
    public static boolean ValidarPreco(String preco){
        return preco.matches("^[1-9]\\d{0,4}\\.\\d{2}$");
    }
    public static boolean ValidarDescricao(String descricao){
        return descricao.matches("^[A-Z][A-Za-zÀ-ÖØ-öø-ÿ\\s]{1,50}$");
    }
    public static boolean ValidarCor(String cor){
        return cor.matches("^[A-Z][a-z]{1,10}(\\s[A-Z][a-z]{1,10})?$");
    }
    public static boolean ValidarTamanho(String tamanho){
        return tamanho.matches("^(PP|P|M|G|GG)$");
    }
    
    public static boolean ValidarTecido(String tecido){
         return tecido.matches("^[A-Z][a-z]{1,15}(\\s[A-Z][a-z]{1,15})?$");
    }
    public static boolean ValidarTipoProduto(String tipoProduto){
         return tipoProduto.matches("^[A-Z][A-Za-zÀ-ÖØ-öø-ÿ\\s]{1,20}$") ;
    }
    public static boolean ValidarURL(String url){
         return url.matches("^(https?:\\/\\/.*\\.(?:png|jpg|jpeg|gif|bmp|webp|svg))$");
    }
    
    
    
    
    
}
