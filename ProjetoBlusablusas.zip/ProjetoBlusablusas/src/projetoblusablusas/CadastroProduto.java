/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class CadastroProduto extends javax.swing.JInternalFrame {

   CadastroFuncionário cf = new CadastroFuncionário();
   String situacaoEstoque;
    public CadastroProduto() {
        initComponents();
        atualizarTabelaEstoque();
        designer();
        this.codigo.setEnabled(false);
        
      
    }
public void designer(){
        this.tabelaEstoque.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEstoque.getTableHeader().setOpaque(false);
        this.tabelaEstoque.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEstoque.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEstoque.setRowHeight(25);
        
    
  }
    
    
    
    
    
    
   public void atualizarTabelaEstoque(){
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT * FROM CadastroProduto;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaestoquecritico = (DefaultTableModel) this.tabelaEstoque.getModel();
            tabelaestoquecritico.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("Preço"),rs.getString("SituacaoProduto"),rs.getString("Descricao"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaestoquecritico.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }
   
   public void salvarProduto(){
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
            String sql ="INSERT INTO descricao(descricao,cor,tecido,tamanho,categoria,imagem_url)VALUES(?,?,?,?,?,?)";
            PreparedStatement stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.descricao.getText());
            stmt.setString(2, this.cor.getText());
            stmt.setString(3, this.tecido.getText());
            stmt.setString(4, this.tamanho.getText());
            stmt.setString(5, this.categoria.getText());
            stmt.setString(6,this.url.getText());
            stmt.execute();
            sql = "INSERT INTO produto(denominacao,quantidade_estoque,preco,id_descricao)VALUES(?,?,?,(SELECT id_descricao FROM descricao ORDER BY id_descricao DESC LIMIT 1));";
            stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.produto.getText());
            stmt.setString(2, this.estoque.getText());
            stmt.setString(3, this.preco.getText());
            stmt.execute();
            stmt.close();
            coin.close();
            atualizarTabelaEstoque();
            
             
        } catch (SQLException ex) {
            Logger.getLogger(CadastroProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        
        
       
   }
   
public void editarProduto(){
        try {
         Connection coin = conexaoBancoDeDados.conexaoBanco();
         String sql = "UPDATE descricao SET descricao = ?,cor=?,tecido=?,tamanho=?,categoria=?,imagem_url=? WHERE id_descricao=?;";
         PreparedStatement stmt = coin.prepareStatement(sql);
         stmt.setString(1, this.descricao.getText());
         stmt.setString(2, this.cor.getText());
         stmt.setString(3, this.tecido.getText());
         stmt.setString(4, this.tamanho.getText());
         stmt.setString(5, this.categoria.getText());
         stmt.setString(6,this.url.getText());
         stmt.setString(7, this.codigo.getText());
         stmt.executeUpdate();
         sql = "UPDATE produto SET denominacao = ?,quantidade_estoque=?, preco = ?,situacao = ?  WHERE id_descricao=?;";
         stmt= coin.prepareStatement(sql);
         stmt.setString(1, this.produto.getText());
         stmt.setString(2, this.estoque.getText());
         stmt.setString(3, this.preco.getText());
         stmt.setString(4, this.situacaoEstoque);
         stmt.setString(5, this.codigo.getText());
         stmt.executeUpdate();
         stmt.close();
         coin.close();
         JOptionPane.showMessageDialog(null, "Produto alterado com sucesso");
         cf.limparCampos();
      
         
         
           
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionário.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
       
       
   }
   
   
    
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        produto = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        codigo = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        estoque = new javax.swing.JTextField();
        categoria = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        preco = new javax.swing.JTextField();
        descricao = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        cor = new javax.swing.JTextField();
        tecido = new javax.swing.JTextField();
        tamanho = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelaEstoque = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        url = new javax.swing.JTextField();
        radioAtivo = new javax.swing.JRadioButton();
        radioEsgotado = new javax.swing.JRadioButton();
        radioDescontinuado = new javax.swing.JRadioButton();
        jButton2 = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel3.setBackground(new java.awt.Color(102, 0, 102));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Cadastro de Produto");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(16, 16, 16))
        );

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("Tipo de Produto");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Tecido");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("Cor");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("Descrição");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Estoque");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setText("Código");

        categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoriaActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setText("Produto");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("Tamanho");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setText("Preço");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setText("Situação");

        cor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                corActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel24.setText("Tabela de Estoque");

        jButton4.setBackground(new java.awt.Color(153, 0, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Salva");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(153, 0, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Editar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(153, 0, 153));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Excluir");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        tabelaEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Produto", "QuantidadenoEstoque", "Preço", "SituacaoProduto", "Descricao", "Cor", "Tecido", "Tamanho", "Categoria", "URL"
            }
        ));
        tabelaEstoque.setSelectionBackground(new java.awt.Color(153, 0, 153));
        tabelaEstoque.setSelectionForeground(new java.awt.Color(255, 255, 255));
        tabelaEstoque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaEstoqueMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabelaEstoque);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Produto mais vendidos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setText("URL");

        buttonGroup1.add(radioAtivo);
        radioAtivo.setText("Ativo");
        radioAtivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioAtivoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioEsgotado);
        radioEsgotado.setText("Esgotado");
        radioEsgotado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioEsgotadoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioDescontinuado);
        radioDescontinuado.setText("Descontinuado");
        radioDescontinuado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDescontinuadoActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(153, 0, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Limpar Campos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel23)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel19)
                                        .addComponent(jLabel20))
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel25))
                                .addGap(2, 2, 2))
                            .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tamanho)
                            .addComponent(tecido)
                            .addComponent(cor)
                            .addComponent(descricao)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(categoria)
                            .addComponent(url, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(produto)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(radioAtivo)
                                        .addGap(18, 18, 18)
                                        .addComponent(radioEsgotado)
                                        .addGap(18, 18, 18)
                                        .addComponent(radioDescontinuado)
                                        .addGap(0, 108, Short.MAX_VALUE))
                                    .addComponent(preco)
                                    .addComponent(estoque))))
                        .addGap(159, 159, 159))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(jButton6)
                        .addGap(65, 65, 65)
                        .addComponent(jButton4)
                        .addGap(76, 76, 76)
                        .addComponent(jButton5)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel24)
                        .addGap(277, 277, 277)
                        .addComponent(jButton1)
                        .addGap(429, 429, 429))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1041, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel21)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel14))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19))
                                .addGap(28, 28, 28)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(produto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(estoque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel18))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(preco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel23)
                                    .addComponent(radioAtivo)
                                    .addComponent(radioEsgotado)
                                    .addComponent(radioDescontinuado))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(descricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel16))
                                .addGap(18, 18, 18)
                                .addComponent(tecido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(tamanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(url, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton6)
                            .addComponent(jButton4)
                            .addComponent(jButton5))
                        .addGap(30, 30, 30)
                        .addComponent(jButton2)
                        .addGap(0, 77, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jLabel24))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButton1)))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3)))
                .addGap(63, 63, 63))
        );

        jScrollPane2.setViewportView(jPanel2);

        getContentPane().add(jScrollPane2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        ProdutosMaisVendidos pmv = new  ProdutosMaisVendidos(null,true);
        pmv.setVisible(true);

    }//GEN-LAST:event_jButton1ActionPerformed

    private void corActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_corActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_corActionPerformed

    private void categoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categoriaActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       String mensagem = JOptionPane.showInputDialog("Autorização para cadastrar Funcionários");
       if(mensagem.equals("senha123")){
           salvarProduto();
       }else{
           JOptionPane.showMessageDialog(null, "Autorizacão Cancelada");
       }
        
        
        
        
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void tabelaEstoqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaEstoqueMouseClicked

      this.produto.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 1).toString());
      this.estoque.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 2).toString());
      this.preco.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 3).toString());
      this.descricao.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 5).toString());
      this.cor.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 6).toString());
      this.tecido.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 7).toString());
      this.tamanho.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 8).toString());
      this.categoria.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 9).toString());
      this.url.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 10).toString());
      this.codigo.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 0).toString());
      situacaoEstoque = this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 4).toString();
      
      if(situacaoEstoque.equals("Ativo")){
          this.radioAtivo.setSelected(true);
      }else if(situacaoEstoque.equals("Esgotado")){
          this.radioEsgotado.setSelected(true);
      }else if(situacaoEstoque.equals("Descontinuado")){
          this.radioDescontinuado.setSelected(true);
      }
      
      
     
     
        
        
    }//GEN-LAST:event_tabelaEstoqueMouseClicked

    private void radioAtivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioAtivoActionPerformed
        situacaoEstoque = "Ativo";
    }//GEN-LAST:event_radioAtivoActionPerformed

    private void radioEsgotadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioEsgotadoActionPerformed
       situacaoEstoque = "Esgotado";
    }//GEN-LAST:event_radioEsgotadoActionPerformed

    private void radioDescontinuadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDescontinuadoActionPerformed
        situacaoEstoque = "Descontinuado";
    }//GEN-LAST:event_radioDescontinuadoActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       editarProduto();
       atualizarTabelaEstoque();
       
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
            int resposta = JOptionPane.showConfirmDialog(null,
        "Tem certeza que deseja excluir este produto?\nEssa ação também removerá os dados importantes e sensivéis.",
       "Confirmar Exclusão",
      JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        
        if(resposta== JOptionPane.YES_NO_OPTION){
             try {
           Connection coin = conexaoBancoDeDados.conexaoBanco();
           String sql = "DELETE FROM produto WHERE id_produto=?;";
           PreparedStatement stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigo.getText());
           stmt.execute();
           sql = "DELETE FROM descricao WHERE id_descricao = ?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigo.getText());
        
          
               stmt.execute();
               JOptionPane.showMessageDialog(null, "Produto Deletado");
               stmt.close();
               coin.close();
                atualizarTabelaEstoque();
              
               
               
          
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionário.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
            
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     this.produto.setText(null);
     this.codigo.setText(null);
     this.estoque.setText(null);
     this.preco.setText(null);
     this.descricao.setText(null);
     this.cor.setText(null);
     this.tecido.setText(null);
     this.tamanho.setText(null);
     this.categoria.setText(null);
     this.url.setText(null);
     this.radioAtivo.setSelected(false);
     this.radioDescontinuado.setSelected(false);
     this.radioEsgotado.setSelected(false);
     
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField categoria;
    private javax.swing.JTextField codigo;
    private javax.swing.JTextField cor;
    private javax.swing.JTextField descricao;
    private javax.swing.JTextField estoque;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField preco;
    private javax.swing.JTextField produto;
    private javax.swing.JRadioButton radioAtivo;
    private javax.swing.JRadioButton radioDescontinuado;
    private javax.swing.JRadioButton radioEsgotado;
    private javax.swing.JTable tabelaEstoque;
    private javax.swing.JTextField tamanho;
    private javax.swing.JTextField tecido;
    private javax.swing.JTextField url;
    // End of variables declaration//GEN-END:variables
}
