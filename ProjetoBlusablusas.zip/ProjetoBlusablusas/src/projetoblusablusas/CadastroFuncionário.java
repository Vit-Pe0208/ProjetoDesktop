/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class CadastroFuncionário extends javax.swing.JInternalFrame {

   String situacao;
   String genero;
   String dataNascimento;
    public CadastroFuncionário() {
        initComponents();
        designerInicial();
        atualizartabelaAdministrador();
        this.codigopessoa.setEnabled(false);
        
        
      
    }
    
    public void designerInicial(){
         this.TabelaAdministrador.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.TabelaAdministrador.getTableHeader().setOpaque(false);
        this.TabelaAdministrador.getTableHeader().setBackground(new Color(102,0,102));
        this.TabelaAdministrador.getTableHeader().setForeground(Color.WHITE);
        this.TabelaAdministrador.setRowHeight(25);
    }
    
       public void atualizartabelaAdministrador(){
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT \n" +
"p.nome AS Administrador,\n" +
" p.email AS EmailPessoal,\n" +
" p.cpf AS CPF,\n" +
" p.genero AS Gênero,\n" +
" p.data_nascimento AS DataNascimento,\n" +
" adm.matricula AS Matrícula,\n" +
" adm.cargo AS Cargo,\n" +
" adm.situacao AS SituaçãoADM,p.id_pessoa\n" +
" FROM administrador adm\n" +
"INNER JOIN pessoa p ON p.id_pessoa=adm.id_pessoa;";
             
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaadm = (DefaultTableModel) this.TabelaAdministrador.getModel();
            tabelaadm.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Administrador"),rs.getString("EmailPessoal")
                 ,rs.getString("CPF"),rs.getString("Gênero"),rs.getString("DataNascimento"),
                 rs.getString("Matrícula"),rs.getString("Cargo"),rs.getString("SituaçãoADM"),rs.getString("id_pessoa")};
                 tabelaadm.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }
       

  
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        situacaoGrupo = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaAdministrador = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rAtivo = new javax.swing.JRadioButton();
        rInativo = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        matricula = new javax.swing.JTextField();
        nome = new javax.swing.JTextField();
        emailPessoa = new javax.swing.JTextField();
        cargo = new javax.swing.JTextField();
        cpf = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        codigopessoa = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        Feminino = new javax.swing.JRadioButton();
        Masculino = new javax.swing.JRadioButton();
        outro = new javax.swing.JRadioButton();
        calendariodataNascimento = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastro de Administradores");

        jPanel1.setBackground(new java.awt.Color(102, 0, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cadastros de Administradores");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1796, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        TabelaAdministrador.setForeground(new java.awt.Color(102, 0, 102));
        TabelaAdministrador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Administrador", "Emai lPessoal", "CPF", "Gênero", "DataNascimento", "Matrícula ADM", "Cargo", "SituaçãoADM", "Código Pessoa"
            }
        ));
        TabelaAdministrador.setSelectionBackground(new java.awt.Color(153, 0, 153));
        TabelaAdministrador.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TabelaAdministrador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelaAdministradorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaAdministrador);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Nome Completo: ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Email Pessoal");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Situação :");

        situacaoGrupo.add(rAtivo);
        rAtivo.setText("Ativo");
        rAtivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rAtivoActionPerformed(evt);
            }
        });

        situacaoGrupo.add(rInativo);
        rInativo.setText("Inativo");
        rInativo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rInativoActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Salvar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Editar");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("Excluir");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("Movimentações de Caixa");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Cargo");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Matrícula :");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Data de Nascimento");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Gênero :");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("CPF");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Tabela de Cadastro de Funcionários");

        jButton5.setText("Pesquisar Código Pessoa");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Código :");

        jButton6.setText("Limpar Campos");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        buttonGroup1.add(Feminino);
        Feminino.setText("Feminino");
        Feminino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FemininoActionPerformed(evt);
            }
        });

        buttonGroup1.add(Masculino);
        Masculino.setText("Masculino");
        Masculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MasculinoActionPerformed(evt);
            }
        });

        buttonGroup1.add(outro);
        outro.setText("Outro");
        outro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                outroActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Tipo de Funcionário : ");

        jRadioButton1.setText("Admin");

        jRadioButton2.setText("Normal");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(342, 342, 342))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel10)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton1))
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel3))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(27, 27, 27)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(Feminino)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(Masculino)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(outro))
                                                    .addComponent(cargo, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(matricula, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(codigopessoa, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(rAtivo)
                                                        .addGap(41, 41, 41)
                                                        .addComponent(rInativo))
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(9, 9, 9)
                                                            .addComponent(jButton2)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(jButton3))
                                                        .addComponent(calendariodataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(jButton6)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(35, 35, 35)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(cpf, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
                                                        .addComponent(emailPessoa, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jRadioButton1)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jRadioButton2)))))))
                                .addGap(103, 103, 103)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(106, 106, 106)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addGap(56, 56, 56)
                                        .addComponent(jButton5))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1218, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(emailPessoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jRadioButton1)
                            .addComponent(jRadioButton2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(Feminino)
                            .addComponent(Masculino)
                            .addComponent(outro))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(calendariodataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(cargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(matricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(codigopessoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(rAtivo)
                            .addComponent(rInativo))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton3))
                        .addGap(33, 33, 33)
                        .addComponent(jButton6))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(jButton5))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        MovimentacaoCaixa mc = new MovimentacaoCaixa(null,true);
        mc.setVisible(true);
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            SimpleDateFormat dataFormatada = new SimpleDateFormat("yyyy-MM-dd");
            dataNascimento = dataFormatada.format(calendariodataNascimento.getDate());
            Connection coin = conexaoBancoDeDados.conexaoBanco();
            String sql = "INSERT INTO pessoa(nome,email,cpf,genero,data_nascimento)\n" +
            "VALUES(?,?,?,?,?);";
            PreparedStatement stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.nome.getText());
            stmt.setString(2, this.emailPessoa.getText());
            stmt.setString(3, this.cpf.getText());
            stmt.setString(4, this.genero);
            stmt.setString(5, dataNascimento);
            stmt.execute();
            
         sql= "INSERT INTO administrador(matricula,cargo,id_pessoa)\n" +
        "VALUES(?,?,(SELECT id_pessoa FROM pessoa ORDER BY id_pessoa DESC LIMIT 1));";
         stmt= coin.prepareStatement(sql);
         stmt.setString(1, this.matricula.getText());
         stmt.setString(2, this.cargo.getText());
         stmt.execute();
         
         stmt.close();
         coin.close();
         JOptionPane.showMessageDialog(null, "Funcionário Cadastrado com Sucesso!!");
         atualizartabelaAdministrador();
       
         
         
         
            
        } catch (SQLException ex) {
            System.getLogger(CadastroFuncionário.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
          
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TabelaAdministradorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelaAdministradorMouseClicked
        this.nome.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 0).toString());
        this.emailPessoa.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 1).toString());
        this.cpf.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 2).toString());
        this.genero=(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 3).toString());
        
        if(genero.equals("Feminino")){
            this.Feminino.setSelected(true);
         }else if(genero.equals("Masculino")){
             this.Masculino.setSelected(true);
         }else if(genero.equals("Outro")){
             this.outro.setSelected(true);
         }
    //    this.dataNasceu.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 5).toString());
        this.matricula.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 5).toString());
        this.cargo.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 6).toString());
        situacao=this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 7).toString();
        
        if(situacao.equals("Ativo")){
            this.rAtivo.setSelected(true);
        }else if(situacao.equals("Inativo")){
            this.rInativo.setSelected(true);
        }
        this.codigopessoa.setText(this.TabelaAdministrador.getValueAt(this.TabelaAdministrador.getSelectedRow(), 8).toString());
    }//GEN-LAST:event_TabelaAdministradorMouseClicked

    private void rAtivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rAtivoActionPerformed
       situacao = "Ativo";
    }//GEN-LAST:event_rAtivoActionPerformed

    private void rInativoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rInativoActionPerformed
        situacao ="Inativo";
    }//GEN-LAST:event_rInativoActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
       try {
         SimpleDateFormat dataFormatada = new SimpleDateFormat("yyyy-MM-DD");
         dataNascimento = dataFormatada.format(calendariodataNascimento.getDate());
         Connection coin = conexaoBancoDeDados.conexaoBanco();
         String sql = "UPDATE pessoa SET nome = ?,email=?,cpf=?,genero=?,data_nascimento=? WHERE id_pessoa=?;";
         PreparedStatement stmt = coin.prepareStatement(sql);
         stmt.setString(1, this.nome.getText());
         stmt.setString(2, this.emailPessoa.getText());
         stmt.setString(3, this.cpf.getText());
         stmt.setString(4, this.genero);
         stmt.setString(5, dataNascimento);
         stmt.setString(6, this.codigopessoa.getText());
         stmt.executeUpdate();
          sql = "UPDATE administrador SET matricula=?,cargo=?,situacao=? WHERE id_pessoa=?;";
         stmt= coin.prepareStatement(sql);
         stmt.setString(1, this.matricula.getText());
         stmt.setString(2, this.cargo.getText());
         stmt.setString(3, situacao);
         stmt.setString(4, this.codigopessoa.getText());
         stmt.executeUpdate();
         stmt.close();
         coin.close();
         JOptionPane.showMessageDialog(null, "Funcionário alterado com sucesso");
         atualizartabelaAdministrador();
         limparCampos();
         
         
           
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionário.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
        
        
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
          
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       limparCampos();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
      int resposta = JOptionPane.showConfirmDialog(null,
        "Tem certeza que deseja excluir este funcionário?\nEssa ação também removerá os dados pessoais.",
       "Confirmar Exclusão",
      JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        
        if(resposta== JOptionPane.YES_NO_OPTION){
             try {
           Connection coin = conexaoBancoDeDados.conexaoBanco();
           
           String sql = "DELETE FROM login WHERE id_pessoa=?;";
           PreparedStatement stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.codigopessoa.getText());
           stmt.execute();
           sql = "DELETE FROM administrador WHERE id_pessoa = ?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigopessoa.getText());
           stmt.execute();
           sql = "DELETE FROM pessoa WHERE id_pessoa=?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigopessoa.getText());
        
          
               stmt.execute();
               JOptionPane.showMessageDialog(null, "Funcionário Deletado");
               stmt.close();
               coin.close();
               atualizartabelaAdministrador();
               
               
          
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionário.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
            
        }
       
      
    }//GEN-LAST:event_jButton3MouseClicked

    private void FemininoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FemininoActionPerformed
        genero = "Feminino";
    }//GEN-LAST:event_FemininoActionPerformed

    private void MasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MasculinoActionPerformed
        genero = "Masculino";
    }//GEN-LAST:event_MasculinoActionPerformed

    private void outroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_outroActionPerformed
       genero = "Outro";
    }//GEN-LAST:event_outroActionPerformed
public void limparCampos(){
    this.nome.setText(null);
    this.cpf.setText(null);
    this.emailPessoa.setText(null);
    //this.dataNasceu.setText(null);
    this.matricula.setText(null);
    this.cargo.setText(null);
    this.codigopessoa.setText(null);
    this.Feminino.setSelected(false);
    this.Masculino.setSelected(false);
    this.outro.setSelected(false);
    this.rAtivo.setSelected(false);
    this.rInativo.setSelected(false);
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Feminino;
    private javax.swing.JRadioButton Masculino;
    private javax.swing.JTable TabelaAdministrador;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private com.toedter.calendar.JDateChooser calendariodataNascimento;
    private javax.swing.JTextField cargo;
    private javax.swing.JTextField codigopessoa;
    private javax.swing.JTextField cpf;
    private javax.swing.JTextField emailPessoa;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField matricula;
    private javax.swing.JTextField nome;
    private javax.swing.JRadioButton outro;
    private javax.swing.JRadioButton rAtivo;
    private javax.swing.JRadioButton rInativo;
    private javax.swing.ButtonGroup situacaoGrupo;
    // End of variables declaration//GEN-END:variables
}
