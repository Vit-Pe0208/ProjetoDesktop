/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import projetoblusablusas.Home;

/**
 *
 * @author User
 */
public class TelaDeRelatório0 extends javax.swing.JInternalFrame {

    /**
     * Creates new form TelaDeRelatório
     */
    public TelaDeRelatório0() {
        initComponents();
        this.produtosmaisVendidos.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.produtosmaisVendidos.getTableHeader().setOpaque(false);
        this.produtosmaisVendidos.getTableHeader().setBackground(new Color(102,0,102));
        this.produtosmaisVendidos.getTableHeader().setForeground(Color.WHITE);
        this.produtosmaisVendidos.setRowHeight(25);
        
        this.relatorioVendasPorcliente.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.relatorioVendasPorcliente.getTableHeader().setOpaque(false);
        this.relatorioVendasPorcliente.getTableHeader().setBackground(new Color(102,0,102));
        this.relatorioVendasPorcliente.getTableHeader().setForeground(Color.WHITE);
        this.relatorioVendasPorcliente.setRowHeight(25);
        
        this.tabelaPagamento.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaPagamento.getTableHeader().setOpaque(false);
        this.tabelaPagamento.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaPagamento.getTableHeader().setForeground(Color.WHITE);
        this.tabelaPagamento.setRowHeight(25);
        
        this.tabelaEstoque.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEstoque.getTableHeader().setOpaque(false);
        this.tabelaEstoque.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEstoque.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEstoque.setRowHeight(25);
        
        this.tabelaEndereco.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEndereco.getTableHeader().setOpaque(false);
        this.tabelaEndereco.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEndereco.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEndereco.setRowHeight(25);
        
        atualizarRelatorioProdutosVendidos();
        relatoriorelatorioVendasPorcliente();
        tabelaEstoque();
        relatorioPagamento();
        graficoPizzaProdutos();
        graficoVendasPorUsuario();
        graficoPizzaPagamento();
        graficoPizzaEstoqueProdutos();
      
        
       
    }

   public void graficoPizzaProdutos() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT p.denominacao, SUM(iv.quantidade_venda) AS QuantidadedeVendas " +
                     "FROM itens_venda iv " +
                     "INNER JOIN produto p ON p.id_produto = iv.id_produto " +
                     "GROUP BY p.id_produto, p.denominacao " +
                     "HAVING SUM(iv.quantidade_venda) >= 3 " +
                     "ORDER BY QuantidadedeVendas DESC";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

       
        while (rs.next()) {
            String denominacao = rs.getString("denominacao");
            double quantidade = rs.getDouble("QuantidadedeVendas");
            pieDataset.setValue(denominacao, quantidade);
        }

        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Produtos Mais Vendidos",
        pieDataset,
        true,   
        true,   
        false   
    );

    // Painel do gráfico
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
    chartPanel.setMouseWheelEnabled(true);

    
    painelGrafico.removeAll(); 
    painelGrafico.setLayout(new java.awt.BorderLayout()); 
    painelGrafico.add(chartPanel, BorderLayout.CENTER); 
    painelGrafico.revalidate();
    painelGrafico.repaint();    
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        produtosmaisVendidos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        painelGrafico = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        relatorioVendasPorcliente = new javax.swing.JTable();
        painelGraficoVendasporCliente = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelaPagamento = new javax.swing.JTable();
        painelGraficoPagamento = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelaEndereco = new javax.swing.JTable();
        painelEndereço = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabelaEstoque = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        painelGraficoProduto = new javax.swing.JPanel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Relatórios");

        produtosmaisVendidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade de Vendas", "Código do Produto"
            }
        ));
        produtosmaisVendidos.setSelectionBackground(new java.awt.Color(102, 0, 102));
        produtosmaisVendidos.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(produtosmaisVendidos);

        jLabel1.setText("Pesquisar Produto : ");

        javax.swing.GroupLayout painelGraficoLayout = new javax.swing.GroupLayout(painelGrafico);
        painelGrafico.setLayout(painelGraficoLayout);
        painelGraficoLayout.setHorizontalGroup(
            painelGraficoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 615, Short.MAX_VALUE)
        );
        painelGraficoLayout.setVerticalGroup(
            painelGraficoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 312, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(painelGrafico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelGrafico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Produtos mais vendidos", jPanel1);

        jLabel4.setText("Pesquisar CPF:");

        relatorioVendasPorcliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Usuário", "CPF", "Email", "Código Usuario", "Valor Total"
            }
        ));
        jScrollPane4.setViewportView(relatorioVendasPorcliente);

        javax.swing.GroupLayout painelGraficoVendasporClienteLayout = new javax.swing.GroupLayout(painelGraficoVendasporCliente);
        painelGraficoVendasporCliente.setLayout(painelGraficoVendasporClienteLayout);
        painelGraficoVendasporClienteLayout.setHorizontalGroup(
            painelGraficoVendasporClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 404, Short.MAX_VALUE)
        );
        painelGraficoVendasporClienteLayout.setVerticalGroup(
            painelGraficoVendasporClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(painelGraficoVendasporCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(330, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(painelGraficoVendasporCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE))
                .addContainerGap(113, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Vendas por clientes", jPanel2);

        jLabel5.setText("Tipo de Pagamento");

        tabelaPagamento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Pagamento", "R$", "Quantidade de vezes"
            }
        ));
        jScrollPane5.setViewportView(tabelaPagamento);

        javax.swing.GroupLayout painelGraficoPagamentoLayout = new javax.swing.GroupLayout(painelGraficoPagamento);
        painelGraficoPagamento.setLayout(painelGraficoPagamentoLayout);
        painelGraficoPagamentoLayout.setHorizontalGroup(
            painelGraficoPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 395, Short.MAX_VALUE)
        );
        painelGraficoPagamentoLayout.setVerticalGroup(
            painelGraficoPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 224, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(painelGraficoPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(242, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(70, 70, 70)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(painelGraficoPagamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE))
                .addContainerGap(107, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Pagamentos", jPanel3);

        jLabel3.setText("Estado :");

        tabelaEndereco.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Estado", "Tipo de Residência"
            }
        ));
        jScrollPane3.setViewportView(tabelaEndereco);

        javax.swing.GroupLayout painelEndereçoLayout = new javax.swing.GroupLayout(painelEndereço);
        painelEndereço.setLayout(painelEndereçoLayout);
        painelEndereçoLayout.setHorizontalGroup(
            painelEndereçoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 435, Short.MAX_VALUE)
        );
        painelEndereçoLayout.setVerticalGroup(
            painelEndereçoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 234, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(painelEndereço, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(309, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelEndereço, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(81, 81, 81))
        );

        tabbedPane.addTab("Estados", jPanel5);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Email", "Telefone", "CPF", "Situacao", "Genero", "dataNascimento", "dataCadastro"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 924, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Pessoas", jPanel7);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_produto", "denominacao", "quantidadeEstoque", "preco", "situacao"
            }
        ));
        jScrollPane7.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 683, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(165, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47))
        );

        jTabbedPane1.addTab("produtos", jPanel8);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_venda", "desconto", "acrescimo", "cupom", "dataCompra", "valorTotal", "situacao"
            }
        ));
        jScrollPane8.setViewportView(jTable3);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 859, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(92, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(60, Short.MAX_VALUE)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47))
        );

        jTabbedPane1.addTab("Vendas", jPanel9);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Deletações");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 957, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Deletações", jPanel6);

        tabelaEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Produto", "Quantidade", "Preco", "Situação"
            }
        ));
        jScrollPane6.setViewportView(tabelaEstoque);

        jLabel2.setText("Produto: ");

        javax.swing.GroupLayout painelGraficoProdutoLayout = new javax.swing.GroupLayout(painelGraficoProduto);
        painelGraficoProduto.setLayout(painelGraficoProdutoLayout);
        painelGraficoProdutoLayout.setHorizontalGroup(
            painelGraficoProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 555, Short.MAX_VALUE)
        );
        painelGraficoProdutoLayout.setVerticalGroup(
            painelGraficoProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 224, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 637, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(painelGraficoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(painelGraficoProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(141, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Estoque", jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabbedPane)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

       public void atualizarRelatorioProdutosVendidos(){
            try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT\n" +
"p.denominacao,\n" +
"SUM(iv.quantidade_venda) AS QuantidadedeVendas,\n" +
"p.id_produto\n" +
" FROM itens_venda iv\n" +
" INNER JOIN  produto p ON p.id_produto = iv.id_produto\n" +
" GROUP BY id_produto\n HAVING SUM(iv.quantidade_venda) >=3" +
" ORDER BY QuantidadedeVendas DESC;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaestoquecritico = (DefaultTableModel) this.produtosmaisVendidos.getModel();
            tabelaestoquecritico.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("denominacao"),rs.getString("QuantidadedeVendas"),rs.getString("id_produto")};
                 tabelaestoquecritico.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
       }
       
   
    public void graficoVendasPorUsuario() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT p.nome AS Usuário, SUM(v.valor_total) AS ValorTotal " +
                     "FROM venda v " +
                     "INNER JOIN usuario u ON u.id_usuario = v.id_usuario " +
                     "INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa " +
                     "GROUP BY p.id_pessoa, p.nome " +
                     "ORDER BY ValorTotal DESC";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        
        while (rs.next()) {
            String usuario = rs.getString("Usuário");
            double valorTotal = rs.getDouble("ValorTotal");
            pieDataset.setValue(usuario, valorTotal);
        }

        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    
    JFreeChart chart = ChartFactory.createPieChart(
        "Resumo de Vendas por Cliente",
        pieDataset,
        true,   
        true,   
        false   
    );

    
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
    chartPanel.setMouseWheelEnabled(true);

    
    this.painelGraficoVendasporCliente.removeAll(); 
    painelGraficoVendasporCliente.setLayout(new java.awt.BorderLayout()); 
    painelGraficoVendasporCliente.add(chartPanel, BorderLayout.CENTER); 
    painelGraficoVendasporCliente.revalidate(); 
    painelGraficoVendasporCliente.repaint();    
}
    
    public void relatoriorelatorioVendasPorcliente(){
        Connection coin;
        try {
            coin = conexaoBancoDeDados.conexaoBanco();
            String sql = " SELECT \n" +
" p.nome AS Usuário,\n" +
" p.cpf AS CPF,\n" +
" p.email AS EMAIL,\n" +
" u.id_pessoa,\n" +
" SUM(v.valor_total) AS ValorTotal\n" +
" FROM venda v\n" +
" INNER JOIN usuario u ON u.id_usuario = v.id_usuario\n" +
" INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa\n" +
"GROUP BY  p.id_pessoa, p.nome, p.cpf, p.email\n" +
"ORDER BY ValorTotal DESC;";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        DefaultTableModel tabelavendasPorCliente = (DefaultTableModel) this.relatorioVendasPorcliente.getModel();
         tabelavendasPorCliente.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Usuário"),rs.getString("CPF"),rs.getString("EMAIL"),rs.getString("id_pessoa"),rs.getString("ValorTotal")};
                 tabelavendasPorCliente.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
        
        } catch (SQLException ex) {
            System.getLogger(TelaDeRelatório0.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        
        
    }
    
    public void relatorioPagamento(){
        
         try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT\n" +
"p.forma_pagamento,\n" +
"SUM(p.valor) AS TotalValores,\n" +
"COUNT(p.forma_pagamento) AS Tipodepagamentorealizado\n" +
"FROM pagamento p\n" +
"GROUP BY forma_pagamento;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelapagamento = (DefaultTableModel) this.tabelaPagamento.getModel();
            tabelapagamento.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("forma_pagamento"),rs.getString("TotalValores"),rs.getString("Tipodepagamentorealizado")};
                 tabelapagamento.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
        
    }
    
    public void graficoPizzaPagamento() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT p.forma_pagamento, SUM(p.valor) AS TotalValores " +
                     "FROM pagamento p " +
                     "GROUP BY p.forma_pagamento";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        
        while (rs.next()) {
            String formaPagamento = rs.getString("forma_pagamento");
            double totalValores = rs.getDouble("TotalValores");
            pieDataset.setValue(formaPagamento, totalValores);
        }

        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Distribuição das Formas de Pagamento",
        pieDataset,
        true,   
        true,   
        false  
    );

    
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
    chartPanel.setMouseWheelEnabled(true);

    
    painelGraficoPagamento.removeAll(); 
    painelGraficoPagamento.setLayout(new java.awt.BorderLayout()); 
    painelGraficoPagamento.add(chartPanel, BorderLayout.CENTER); 
    painelGraficoPagamento.revalidate(); 
    painelGraficoPagamento.repaint();   
}
    
   public void tabelaEstoque(){
       
          
         try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT * FROM produto WHERE situacao = 'Ativo' && quantidade_estoque >10 ;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaEstoque = (DefaultTableModel) this.tabelaEstoque.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_produto"),rs.getString("denominacao"),rs.getString("quantidade_estoque"),rs.getString("preco"),rs.getString("situacao")};
                 tabelaEstoque.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
       
   }
   
 public void graficoPizzaEstoqueProdutos() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT denominacao, quantidade_estoque FROM produto WHERE situacao = 'Ativo' && quantidade_estoque >10 ;";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            String produto = rs.getString("denominacao");
            int quantidade = rs.getInt("quantidade_estoque");
            pieDataset.setValue(produto, quantidade);
        }
        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Estoque dos Produtos Ativos",
        pieDataset,
        true,  
        true,   
        false  
    );

    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(600, 350));
    chartPanel.setMouseWheelEnabled(true);

    painelGraficoProduto.removeAll();
    painelGraficoProduto.setLayout(new java.awt.BorderLayout());
   painelGraficoProduto.add(chartPanel, java.awt.BorderLayout.CENTER);
    painelGraficoProduto.revalidate();
    painelGraficoProduto.repaint();
}
   
   
    
    
    
    
   
     



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JPanel painelEndereço;
    private javax.swing.JPanel painelGrafico;
    private javax.swing.JPanel painelGraficoPagamento;
    private javax.swing.JPanel painelGraficoProduto;
    private javax.swing.JPanel painelGraficoVendasporCliente;
    private javax.swing.JTable produtosmaisVendidos;
    private javax.swing.JTable relatorioVendasPorcliente;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabelaEndereco;
    public javax.swing.JTable tabelaEstoque;
    private javax.swing.JTable tabelaPagamento;
    // End of variables declaration//GEN-END:variables
}
