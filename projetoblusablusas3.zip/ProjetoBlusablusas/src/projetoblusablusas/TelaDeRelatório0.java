/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import projetoblusablusas.Home;

/**
 *
 * @author User
 */
public class TelaDeRelatório0 extends javax.swing.JInternalFrame {

   String uf;
    public TelaDeRelatório0() {
        initComponents();
        this.produtosmaisVendidos.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.produtosmaisVendidos.getTableHeader().setOpaque(false);
        this.produtosmaisVendidos.getTableHeader().setBackground(new Color(102,0,102));
        this.produtosmaisVendidos.getTableHeader().setForeground(Color.WHITE);
        this.produtosmaisVendidos.setRowHeight(25);
        
        this.relatorioVendasPorcliente.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.relatorioVendasPorcliente.getTableHeader().setOpaque(false);
        this.relatorioVendasPorcliente.getTableHeader().setBackground(new Color(102,0,102));
        this.relatorioVendasPorcliente.getTableHeader().setForeground(Color.WHITE);
        this.relatorioVendasPorcliente.setRowHeight(25);
        
        this.tabelaPagamento.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaPagamento.getTableHeader().setOpaque(false);
        this.tabelaPagamento.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaPagamento.getTableHeader().setForeground(Color.WHITE);
        this.tabelaPagamento.setRowHeight(25);
        
        this.tabelaEstoque.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEstoque.getTableHeader().setOpaque(false);
        this.tabelaEstoque.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEstoque.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEstoque.setRowHeight(25);
        
        this.tabelaEndereco.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEndereco.getTableHeader().setOpaque(false);
        this.tabelaEndereco.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEndereco.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEndereco.setRowHeight(25);
        
        this.produtotabela.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.produtotabela.getTableHeader().setOpaque(false);
        this.produtotabela.getTableHeader().setBackground(new Color(102,0,102));
        this.produtotabela.getTableHeader().setForeground(Color.WHITE);
        this.produtotabela.setRowHeight(25);
        
        this.tabelaVendaPorperiodo.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaVendaPorperiodo.getTableHeader().setOpaque(false);
        this.tabelaVendaPorperiodo.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaVendaPorperiodo.getTableHeader().setForeground(Color.WHITE);
        this.tabelaVendaPorperiodo.setRowHeight(25);
        
        atualizarRelatorioProdutosVendidos();
        VendasPorPeriodo();
        relatoriorelatorioVendasPorcliente();
        tabelaEstoque();
        tabelaProduto();
        relatorioPagamento();
        graficoPizzaProdutos();
        graficoVendasPorUsuario();
        graficoPizzaPagamento();
        graficoPizzaEstoqueProdutos();
        graficoEstados();
        atualizaestados();
        deletapessoa();
        deletacao();
        graficoVendasPorPeriodo();
      
        
       
    }
    //Gráficos
    public void graficoPizzaProdutos() {
   DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT p.denominacao, SUM(iv.quantidade) AS QuantidadedeVendas " +
                     "FROM itens_venda iv " +
                     "INNER JOIN produto p ON p.id_produto = iv.id_produto " +
                     "GROUP BY p.id_produto, p.denominacao " +
                     "HAVING SUM(iv.quantidade) >= 3 " +
                     "ORDER BY QuantidadedeVendas DESC";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

       
        while (rs.next()) {
            String denominacao = rs.getString("denominacao");
            double quantidade = rs.getDouble("QuantidadedeVendas");
            pieDataset.setValue(denominacao, quantidade);
        }

        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Produtos Mais Vendidos",
        pieDataset,
        true,   
        true,   
        false   
    );

    // Painel do gráfico
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
    chartPanel.setMouseWheelEnabled(true);

    
    painelGrafico.removeAll(); 
    painelGrafico.setLayout(new java.awt.BorderLayout()); 
    painelGrafico.add(chartPanel, BorderLayout.CENTER); 
    painelGrafico.revalidate();
    painelGrafico.repaint();      
}
    
    
    
    



 public void graficoVendasPorUsuario() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT p.nome AS Usuário, SUM(v.valor_total) AS ValorTotal " +
                     "FROM venda v " +
                     "INNER JOIN usuario u ON u.id_usuario = v.id_usuario " +
                     "INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa " +
                     "GROUP BY p.id_pessoa, p.nome " +
                     "ORDER BY ValorTotal DESC";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        
        while (rs.next()) {
            String usuario = rs.getString("Usuário");
            double valorTotal = rs.getDouble("ValorTotal");
            pieDataset.setValue(usuario, valorTotal);
        }

        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    
    JFreeChart chart = ChartFactory.createPieChart(
        "Resumo de Vendas por Cliente",
        pieDataset,
        true,   
        true,   
        false   
    );

    
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
    chartPanel.setMouseWheelEnabled(true);

    
    this.painelGraficoVendasporCliente.removeAll(); 
    painelGraficoVendasporCliente.setLayout(new java.awt.BorderLayout()); 
    painelGraficoVendasporCliente.add(chartPanel, BorderLayout.CENTER); 
    painelGraficoVendasporCliente.revalidate(); 
    painelGraficoVendasporCliente.repaint();   
}


 public void graficoPizzaPagamento() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT p.forma_pagamento,SUM(v.valor_total) AS ValorTotal FROM venda v\n" +
"INNER JOIN pagamento p ON p.id_pagamento = v.id_pagamento\n" +
"WHERE p.situacao = 'ativo'\n" +
"GROUP BY p.forma_pagamento;";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        
        while (rs.next()) {
            String formaPagamento = rs.getString("forma_pagamento");
            double totalValores = rs.getDouble("ValorTotal");
            pieDataset.setValue(formaPagamento, totalValores);
        }

        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Distribuição das Formas de Pagamento",
        pieDataset,
        true,   
        true,   
        false  
    );

    
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
    chartPanel.setMouseWheelEnabled(true);

    
    painelGraficoPagamento.removeAll(); 
    painelGraficoPagamento.setLayout(new java.awt.BorderLayout()); 
    painelGraficoPagamento.add(chartPanel, BorderLayout.CENTER); 
    painelGraficoPagamento.revalidate(); 
    painelGraficoPagamento.repaint();   
}


public void graficoPizzaEstoqueProdutos() {
    DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT denominacao, quantidade_estoque FROM produto WHERE situacao = 'ativo' && quantidade_estoque >10 ;";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            String produto = rs.getString("denominacao");
            int quantidade = rs.getInt("quantidade_estoque");
            pieDataset.setValue(produto, quantidade);
        }
        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Estoque dos Produtos Ativos",
        pieDataset,
        true,  
        true,   
        false  
    );

    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(600, 350));
    chartPanel.setMouseWheelEnabled(true);

    painelGraficoProduto.removeAll();
    painelGraficoProduto.setLayout(new java.awt.BorderLayout());
   painelGraficoProduto.add(chartPanel, java.awt.BorderLayout.CENTER);
    painelGraficoProduto.revalidate();
    painelGraficoProduto.repaint();
}

public void graficoEstados(){
      DefaultPieDataset pieDataset = new DefaultPieDataset();
    try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT \n" +
"e.uf,COUNT(e.uf)\n" +
"FROM usuario u \n" +
"INNER JOIN pessoa pu ON pu.id_pessoa = u.id_pessoa\n" +
"INNER JOIN endereco e ON e.id_pessoa=pu.id_pessoa\n" +
"GROUP BY uf;";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            String estado = rs.getString("uf");
            int quantidade = rs.getInt("COUNT(e.uf)");
            pieDataset.setValue(estado, quantidade);
        }
        rs.close();
        stmt.close();
        coin.close();
    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }

    JFreeChart chart = ChartFactory.createPieChart(
        "Estados dos Usuários Cadastrados",
        pieDataset,
        true,  
        true,   
        false  
    );

    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new java.awt.Dimension(600, 350));
    chartPanel.setMouseWheelEnabled(true);

    painelEndereço.removeAll();
    painelEndereço.setLayout(new java.awt.BorderLayout());
    painelEndereço.add(chartPanel, java.awt.BorderLayout.CENTER);
    painelEndereço.revalidate();
    painelEndereço.repaint();
 }
    
    
    

//Relatórios.  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        statusProduto = new javax.swing.ButtonGroup();
        tabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        produtosmaisVendidos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        pesquisarProduto = new javax.swing.JTextField();
        painelGrafico = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        pesquisarCPF = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        relatorioVendasPorcliente = new javax.swing.JTable();
        painelGraficoVendasporCliente = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        pesquisarPagamento = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelaPagamento = new javax.swing.JTable();
        painelGraficoPagamento = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabeladeletadapessoa = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        tabeladeletadaproduto = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabeladeletadavenda = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabelaEstoque = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        pesquisarEstoque = new javax.swing.JTextField();
        painelGraficoProduto = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelaEndereco = new javax.swing.JTable();
        painelEndereço = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tabelaVendaPorperiodo = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        dateInicio = new com.toedter.calendar.JDateChooser();
        jLabel13 = new javax.swing.JLabel();
        dateFinal = new com.toedter.calendar.JDateChooser();
        label = new javax.swing.JLabel();
        resultado = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        panelPeriodovendas = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        pesquisaP = new javax.swing.JTextField();
        jScrollPane9 = new javax.swing.JScrollPane();
        produtotabela = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        ativo = new javax.swing.JRadioButton();
        Descontinuado = new javax.swing.JRadioButton();
        esgotado = new javax.swing.JRadioButton();
        jLabel18 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Relatórios");

        produtosmaisVendidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade de Vendas", "Código do Produto"
            }
        ));
        produtosmaisVendidos.setSelectionBackground(new java.awt.Color(102, 0, 102));
        produtosmaisVendidos.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(produtosmaisVendidos);

        jLabel1.setText("Pesquisar Produto : ");

        pesquisarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisarProdutoActionPerformed(evt);
            }
        });
        pesquisarProduto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarProdutoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout painelGraficoLayout = new javax.swing.GroupLayout(painelGrafico);
        painelGrafico.setLayout(painelGraficoLayout);
        painelGraficoLayout.setHorizontalGroup(
            painelGraficoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 878, Short.MAX_VALUE)
        );
        painelGraficoLayout.setVerticalGroup(
            painelGraficoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 545, Short.MAX_VALUE)
        );

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("Tabela de produtos mais vendidos");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pesquisarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 698, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(100, 100, 100)
                        .addComponent(painelGrafico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(195, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(pesquisarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelGrafico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(139, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Produtos mais vendidos", jPanel1);

        jLabel4.setText("Pesquisar CPF:");

        pesquisarCPF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarCPFKeyPressed(evt);
            }
        });

        relatorioVendasPorcliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Usuário", "CPF", "Email", "Código Usuario", "Valor Total"
            }
        ));
        jScrollPane4.setViewportView(relatorioVendasPorcliente);

        javax.swing.GroupLayout painelGraficoVendasporClienteLayout = new javax.swing.GroupLayout(painelGraficoVendasporCliente);
        painelGraficoVendasporCliente.setLayout(painelGraficoVendasporClienteLayout);
        painelGraficoVendasporClienteLayout.setHorizontalGroup(
            painelGraficoVendasporClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 797, Short.MAX_VALUE)
        );
        painelGraficoVendasporClienteLayout.setVerticalGroup(
            painelGraficoVendasporClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 503, Short.MAX_VALUE)
        );

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Tabela de vendas por clientes");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(pesquisarCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(170, 170, 170)
                        .addComponent(painelGraficoVendasporCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(180, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(pesquisarCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jLabel15)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelGraficoVendasporCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(159, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Vendas por clientes", jPanel2);

        jLabel5.setText("Tipo de Pagamento");

        pesquisarPagamento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarPagamentoKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pesquisarPagamentoKeyReleased(evt);
            }
        });

        tabelaPagamento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Pagamento", "R$", "Quantidade de vezes"
            }
        ));
        jScrollPane5.setViewportView(tabelaPagamento);

        javax.swing.GroupLayout painelGraficoPagamentoLayout = new javax.swing.GroupLayout(painelGraficoPagamento);
        painelGraficoPagamento.setLayout(painelGraficoPagamentoLayout);
        painelGraficoPagamentoLayout.setHorizontalGroup(
            painelGraficoPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 804, Short.MAX_VALUE)
        );
        painelGraficoPagamentoLayout.setVerticalGroup(
            painelGraficoPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 482, Short.MAX_VALUE)
        );

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("Tabela de quantiodade de tipos de pagamentos.");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pesquisarPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 708, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(88, 88, 88)
                        .addComponent(painelGraficoPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(248, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(pesquisarPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelGraficoPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(174, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Pagamentos", jPanel3);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Deletações");

        tabeladeletadapessoa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Email", "CPF", "Genero", "dataNascimento", "dataCadastro"
            }
        ));
        jScrollPane2.setViewportView(tabeladeletadapessoa);

        tabeladeletadaproduto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_produto", "denominacao", "quantidadeEstoque", "preco"
            }
        ));
        jScrollPane7.setViewportView(tabeladeletadaproduto);

        tabeladeletadavenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_venda", "desconto", "acrescimo", "cupom", "dataCompra", "valorTotal"
            }
        ));
        jScrollPane8.setViewportView(tabeladeletadavenda);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Pessoas");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Vendas");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Produtos");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1228, Short.MAX_VALUE)
                            .addComponent(jScrollPane8)
                            .addComponent(jScrollPane7))))
                .addContainerGap(661, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(14, 14, 14)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Deletações", jPanel6);

        tabelaEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Produto", "Quantidade", "Preco", "Situação"
            }
        ));
        jScrollPane6.setViewportView(tabelaEstoque);

        jLabel2.setText("Produto: ");

        pesquisarEstoque.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarEstoqueKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout painelGraficoProdutoLayout = new javax.swing.GroupLayout(painelGraficoProduto);
        painelGraficoProduto.setLayout(painelGraficoProdutoLayout);
        painelGraficoProdutoLayout.setHorizontalGroup(
            painelGraficoProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 791, Short.MAX_VALUE)
        );
        painelGraficoProdutoLayout.setVerticalGroup(
            painelGraficoProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 489, Short.MAX_VALUE)
        );

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("Tabela de Estoque.");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 637, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150)
                        .addComponent(painelGraficoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pesquisarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(271, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(pesquisarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelGraficoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(148, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Estoque", jPanel4);

        tabelaEndereco.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Estado", "Numeros de cadastros"
            }
        ));
        jScrollPane3.setViewportView(tabelaEndereco);

        javax.swing.GroupLayout painelEndereçoLayout = new javax.swing.GroupLayout(painelEndereço);
        painelEndereço.setLayout(painelEndereçoLayout);
        painelEndereçoLayout.setHorizontalGroup(
            painelEndereçoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 611, Short.MAX_VALUE)
        );
        painelEndereçoLayout.setVerticalGroup(
            painelEndereçoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 518, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 656, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(167, 167, 167)
                .addComponent(painelEndereço, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(412, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(painelEndereço, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(189, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Estados", jPanel5);

        tabelaVendaPorperiodo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cliente", "CPF", "Data", "Valor Total R$", "Código da venda"
            }
        ));
        jScrollPane10.setViewportView(tabelaVendaPorperiodo);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Data início : ");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Data Final: ");

        label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        label.setText("Total : R$  ");

        resultado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        resultado.setText("0");

        jButton1.setBackground(new java.awt.Color(153, 0, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Pesquisar");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        panelPeriodovendas.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setText("Vendas por data");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jScrollPane10)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                    .addComponent(jLabel12)
                                    .addGap(0, 0, 0)
                                    .addComponent(dateInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(32, 32, 32)
                                    .addComponent(jLabel13)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(dateFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(36, 36, 36)
                                    .addComponent(jButton1)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(resultado, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE)
                        .addComponent(panelPeriodovendas, javax.swing.GroupLayout.PREFERRED_SIZE, 828, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(185, 185, 185))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel12)
                        .addComponent(dateInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateFinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(label)
                            .addComponent(resultado)))
                    .addComponent(panelPeriodovendas, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(217, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Vendas Por período", jPanel8);

        jLabel3.setText("Pesquisar Produto : ");

        pesquisaP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisaPActionPerformed(evt);
            }
        });
        pesquisaP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisaPKeyPressed(evt);
            }
        });

        produtotabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Produto", "Estoque", "Preço", "SituacaoProduto", "Descricao", "Cor", "Tecido", "Tamanho", "Categoria", "URL"
            }
        ));
        produtotabela.setSelectionBackground(new java.awt.Color(153, 0, 153));
        produtotabela.setSelectionForeground(new java.awt.Color(255, 255, 255));
        produtotabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                produtotabelaMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(produtotabela);

        jLabel11.setText("Status:");

        statusProduto.add(ativo);
        ativo.setText("Ativo");
        ativo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ativoMouseClicked(evt);
            }
        });

        statusProduto.add(Descontinuado);
        Descontinuado.setText("Descontinuado");
        Descontinuado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DescontinuadoMouseClicked(evt);
            }
        });

        statusProduto.add(esgotado);
        esgotado.setText("Esgotado");
        esgotado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                esgotadoMouseClicked(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Tabela de produtos.");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pesquisaP, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(ativo)
                                .addGap(18, 18, 18)
                                .addComponent(Descontinuado)
                                .addGap(18, 18, 18)
                                .addComponent(esgotado))))
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 1581, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(250, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(pesquisaP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(ativo)
                    .addComponent(Descontinuado)
                    .addComponent(esgotado))
                .addGap(28, 28, 28)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(90, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Produto", jPanel7);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pesquisarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisarProdutoActionPerformed
        
        
    }//GEN-LAST:event_pesquisarProdutoActionPerformed

    private void pesquisarProdutoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarProdutoKeyPressed
         try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.denominacao,\n" +
"SUM(iv.quantidade) AS QuantidadedeVendas,\n" +
"p.id_produto \n" +
"FROM itens_venda iv \n" +
"INNER JOIN produto p ON p.id_produto = iv.id_produto\n" +
"WHERE p.denominacao LIKE '%"+this.pesquisarProduto.getText()+"%'\n" +
"GROUP BY p.id_produto, p.denominacao \n" +
"HAVING SUM(iv.quantidade) >= 3 \n" +
"ORDER BY QuantidadedeVendas DESC;";
             
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaestoquecritico = (DefaultTableModel) this.produtosmaisVendidos.getModel();
            tabelaestoquecritico.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("denominacao"),rs.getString("QuantidadedeVendas"),rs.getString("id_produto")};
                 tabelaestoquecritico.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }//GEN-LAST:event_pesquisarProdutoKeyPressed

    private void pesquisarCPFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarCPFKeyPressed

             Connection coin;
        try {
            coin = conexaoBancoDeDados.conexaoBanco();
            String sql =  
    "SELECT " +
    "pu.nome, " +
    "pu.cpf, " +
    "pu.email, " +
    "pu.id_pessoa, " +
    "SUM(v.valor_total) AS ValorTotal " +
    "FROM venda v " +
    "INNER JOIN usuario u ON u.id_usuario = v.id_usuario " +
    "INNER JOIN pessoa pu ON pu.id_pessoa = u.id_pessoa " +
    "WHERE pu.cpf LIKE '%" + this.pesquisarCPF.getText() + "%' " +
    "GROUP BY pu.cpf;";

            
            
        
   
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        DefaultTableModel tabelavendasPorCliente = (DefaultTableModel) this.relatorioVendasPorcliente.getModel();
         tabelavendasPorCliente.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("nome"),rs.getString("cpf"),rs.getString("email"),rs.getString("id_pessoa"),rs.getString("ValorTotal")};
                 tabelavendasPorCliente.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
        
        } catch (SQLException ex) {
            System.getLogger(TelaDeRelatório.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        
    }//GEN-LAST:event_pesquisarCPFKeyPressed

    private void pesquisarPagamentoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarPagamentoKeyPressed
              try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT\n" +
"p.forma_pagamento,\n" +
"SUM(v.valor_total) AS TotalValores,\n" +
"COUNT(p.forma_pagamento) AS Tipodepagamentorealizado\n" +
"FROM venda v\n" +
"INNER JOIN pagamento p ON p.id_pagamento=v.id_pagamento\n" +
"WHERE p.forma_pagamento LIKE '%"+this.pesquisarPagamento.getText()+"%'                    \n" +
"GROUP BY forma_pagamento;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelapagamento = (DefaultTableModel) this.tabelaPagamento.getModel();
            tabelapagamento.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("forma_pagamento"),rs.getString("TotalValores"),rs.getString("Tipodepagamentorealizado")};
                 tabelapagamento.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }         
    }//GEN-LAST:event_pesquisarPagamentoKeyPressed

    private void pesquisarPagamentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarPagamentoKeyReleased
        
    }//GEN-LAST:event_pesquisarPagamentoKeyReleased

    private void pesquisarEstoqueKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarEstoqueKeyPressed
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT * FROM produto WHERE situacao = 'Ativo' && denominacao LIKE '%"+this.pesquisarEstoque.getText()+"%';";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaEstoque = (DefaultTableModel) this.tabelaEstoque.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_produto"),rs.getString("denominacao"),rs.getString("quantidade_estoque"),rs.getString("preco"),rs.getString("situacao")};
                 tabelaEstoque.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
    }//GEN-LAST:event_pesquisarEstoqueKeyPressed

    private void pesquisaPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisaPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pesquisaPActionPerformed

    private void pesquisaPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisaPKeyPressed
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao WHERE p.denominacao LIKE '%"+this.pesquisaP.getText()+"%';";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaEstoque = (DefaultTableModel) this.produtotabela.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaEstoque.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 


        
        
        
    }//GEN-LAST:event_pesquisaPKeyPressed

    private void ativoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ativoMouseClicked
          try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao WHERE situacao LIKE 'Ativo%';";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
              DefaultTableModel tabelaEstoque = (DefaultTableModel) this.produtotabela.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaEstoque.addRow(array);
             }
             coin.close();
             stmt.close();
             rs.close(); 
            
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 

    }//GEN-LAST:event_ativoMouseClicked

    private void esgotadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_esgotadoMouseClicked
       try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao WHERE situacao LIKE 'Esgotado%';";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
              DefaultTableModel tabelaEstoque = (DefaultTableModel) this.produtotabela.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaEstoque.addRow(array);
             }
             coin.close();
             stmt.close();
             rs.close(); 
            
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 

    }//GEN-LAST:event_esgotadoMouseClicked

    private void DescontinuadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DescontinuadoMouseClicked
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao WHERE situacao LIKE 'Descontinuado%';";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
              DefaultTableModel tabelaEstoque = (DefaultTableModel) this.produtotabela.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaEstoque.addRow(array);
             }
             coin.close();
             stmt.close();
             rs.close(); 
            
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }//GEN-LAST:event_DescontinuadoMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        

    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       try {
               SimpleDateFormat dataFormatada = new SimpleDateFormat("yyyy-MM-dd");
               String data = dataFormatada.format(this.dateInicio.getDate()) + " 00:00:00";
               String data2 =  dataFormatada.format(this.dateFinal.getDate())+ " 23:59:59";
            
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT nome,cpf,data_compra,valor_total,id_venda FROM venda v\n" +
"INNER JOIN usuario u ON u.id_usuario = v.id_usuario\n" +
"INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa\n" +
"WHERE data_compra between ? AND ? ;";
             
             
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             stmt.setString(1, data);
             stmt.setString(2, data2);
             
             
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelavenda = (DefaultTableModel) this.tabelaVendaPorperiodo.getModel();
            tabelavenda.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("nome"),rs.getString("cpf"),rs.getString("data_compra"),rs.getString("valor_total"),rs.getString("id_venda")};
                 tabelavenda.addRow(array);
                 
             }
             
             sql = "SELECT SUM(v.valor_total) AS Total FROM venda v\n" +
"INNER JOIN usuario u ON u.id_usuario = v.id_usuario\n" +
"INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa\n" +
"WHERE data_compra between ? AND ? ;";
             
             stmt = coin.prepareStatement(sql);
             stmt.setString(1, data);
             stmt.setString(2, data2);
             
              rs = stmt.executeQuery();
              
              
              if(rs.next()){
                  String total = rs.getString("Total");
                  
                  if(total==null){
                      this.resultado.setText("0");
                  }else{
                      this.resultado.setText(rs.getString("Total"));
                  }  
              }  
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void produtotabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_produtotabelaMouseClicked

        

    }//GEN-LAST:event_produtotabelaMouseClicked

       public void atualizarRelatorioProdutosVendidos(){
             try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT\n" +
"p.denominacao,\n" +
"SUM(iv.quantidade) AS QuantidadedeVendas,\n" +
"p.id_produto\n" +
" FROM itens_venda iv\n" +
"INNER JOIN  produto p ON p.id_produto = iv.id_produto\n" +
" GROUP BY id_produto HAVING SUM(iv.quantidade) >=3\n" +
" ORDER BY QuantidadedeVendas DESC;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaestoquecritico = (DefaultTableModel) this.produtosmaisVendidos.getModel();
            tabelaestoquecritico.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("denominacao"),rs.getString("QuantidadedeVendas"),rs.getString("id_produto")};
                 tabelaestoquecritico.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
       }
       
   
   
    
    public void relatoriorelatorioVendasPorcliente(){
         Connection coin;
        try {
            coin = conexaoBancoDeDados.conexaoBanco();
            String sql = " SELECT \n" +
" p.nome AS Usuário,\n" +
" p.cpf AS CPF,\n" +
" p.email AS EMAIL,\n" +
" u.id_pessoa,\n" +
" SUM(v.valor_total) AS ValorTotal\n" +
" FROM venda v\n" +
" INNER JOIN usuario u ON u.id_usuario = v.id_usuario\n" +
" INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa\n" +
"GROUP BY  p.id_pessoa, p.nome, p.cpf, p.email\n" +
"ORDER BY ValorTotal DESC;";
        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        DefaultTableModel tabelavendasPorCliente = (DefaultTableModel) this.relatorioVendasPorcliente.getModel();
         tabelavendasPorCliente.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Usuário"),rs.getString("CPF"),rs.getString("EMAIL"),rs.getString("id_pessoa"),rs.getString("ValorTotal")};
                 tabelavendasPorCliente.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
        
        } catch (SQLException ex) {
            System.getLogger(TelaDeRelatório0.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
    
    public void relatorioPagamento(){
         try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT\n" +
"p.forma_pagamento,\n" +
"SUM(v.valor_total)AS TotalValores,\n" +
"COUNT(p.forma_pagamento) AS TipodePagamentorealizado\n" +
"FROM venda v\n" +
"INNER JOIN pagamento p ON p.id_pagamento = v.id_pagamento\n" +
"WHERE p.situacao = 'ativo' \n" +
"GROUP BY forma_pagamento\n" +
";";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelapagamento = (DefaultTableModel) this.tabelaPagamento.getModel();
            tabelapagamento.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("forma_pagamento"),rs.getString("TotalValores"),rs.getString("Tipodepagamentorealizado")};
                 tabelapagamento.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }
    
   
    
   public void tabelaEstoque(){
         try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT * FROM produto WHERE situacao='ativo'";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaEstoque = (DefaultTableModel) this.tabelaEstoque.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_produto"),rs.getString("denominacao"),rs.getString("quantidade_estoque"),rs.getString("preco"),rs.getString("situacao")};
                 tabelaEstoque.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
       
       
   }
   
   
   
 
 
 public void atualizaestados(){
     try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT \n" +
"e.uf,COUNT(e.uf)\n" +
"FROM usuario u \n" +
"INNER JOIN pessoa pu ON pu.id_pessoa = u.id_pessoa\n" +
"INNER JOIN endereco e ON e.id_pessoa=pu.id_pessoa\n" +
"GROUP BY uf;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaendereco = (DefaultTableModel) this.tabelaEndereco.getModel();
            tabelaendereco.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("uf"),rs.getString("COUNT(e.uf)")};
                 tabelaendereco.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
 }
 
 public void deletacao(){
     
      try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT id_pessoa,nome,email,cpf,genero,data_nascimento,data_cadastro FROM pessoas_deletadas;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabeladeletada = (DefaultTableModel) this.tabeladeletadapessoa.getModel();
            tabeladeletada.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_pessoa"),rs.getString("nome"),rs.getString("email"),rs.getString("cpf"),rs.getString("genero"),rs.getString("data_nascimento"),rs.getString("data_cadastro")};
                 tabeladeletada.addRow(array);
                 
             }
             
             sql ="SELECT id_venda,desconto,acrescimo,cupom,data_compra,valor_total FROM vendas_deletadas;";
              stmt = coin.prepareStatement(sql);
              rs = stmt.executeQuery();
             
            DefaultTableModel tabelavenda = (DefaultTableModel) this.tabeladeletadavenda.getModel();
            tabelavenda.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_venda"),rs.getString("desconto"),rs.getString("acrescimo"),rs.getString("cupom"),rs.getString("data_compra"),rs.getString("valor_total")};
                 tabelavenda.addRow(array);
                 
             }
             
              sql ="SELECT id_produto,denominacao,quantidade_estoque,preco FROM produtos_deletados";
              stmt = coin.prepareStatement(sql);
              rs = stmt.executeQuery();
             
            DefaultTableModel tabelaproduto = (DefaultTableModel) this.tabeladeletadaproduto.getModel();
            tabelaproduto.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_produto"),rs.getString("denominacao"),rs.getString("quantidade_estoque"),rs.getString("preco")};
                 tabelaproduto.addRow(array);
                 
             }
             
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }   
 }
 
 public void deletapessoa(){
     try {
             Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT id_pessoa,nome,email,cpf,genero,data_nascimento,data_cadastro FROM pessoas_deletadas;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabeladeletada = (DefaultTableModel) this.tabeladeletadapessoa.getModel();
            tabeladeletada.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_pessoa"),rs.getString("nome"),rs.getString("email"),rs.getString("cpf"),rs.getString("genero"),rs.getString("data_nascimento"),rs.getString("data_cadastro")};
                 tabeladeletada.addRow(array);
                 
             }
             
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }   

     
     
     
 }
 public void tabelaProduto(){
      try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaestoquecritico = (DefaultTableModel) this.produtotabela.getModel();
            tabelaestoquecritico.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaestoquecritico.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  


}
 
 public void VendasPorPeriodo(){
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT nome,cpf,data_compra,valor_total,id_venda FROM venda v\n" +
"INNER JOIN usuario u ON u.id_usuario = v.id_usuario\n" +
"INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa;";

             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelavenda = (DefaultTableModel) this.tabelaVendaPorperiodo.getModel();
            tabelavenda.setNumRows(0);
             while(rs.next()){
                 String dataHora = rs.getString("data_compra");
                 String[] dataCompra = dataHora.split(" ");
                 String data = dataCompra[0];
                 String hora = dataCompra[1];
                 String dataehora = data+"-"+hora;
                 String[] dataCompra2 = dataehora.split("-");
                 String ano = dataCompra2[0];
                 String mes = dataCompra2[1];
                 String dia = dataCompra2[2];
                 
                 Object[] array ={rs.getString("nome"),rs.getString("cpf"),"   "+dia+"/"+mes+"/"+ano+"  "+hora,rs.getString("valor_total"),rs.getString("id_venda")};
                 tabelavenda.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);

        }   
 } 
 
 public void graficoVendasPorPeriodo(){
     try {
        Connection coin = conexaoBancoDeDados.conexaoBanco();
        String sql = "SELECT YEAR(v.data_compra) AS ano, " +
                     "MONTH(v.data_compra) AS mes, " +
                     "SUM(v.valor_total) AS total_vendido " +
                     "FROM venda v " +
                     "GROUP BY YEAR(v.data_compra), MONTH(v.data_compra) " +
                     "ORDER BY ano, mes";

        PreparedStatement stmt = coin.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        DefaultPieDataset dataset = new DefaultPieDataset();

        while (rs.next()) {
            int ano = rs.getInt("ano");
            int mes = rs.getInt("mes");
            double totalVendido = rs.getDouble("total_vendido");

            String rotulo = String.format("%02d/%d", mes, ano);
            dataset.setValue(rotulo, totalVendido);
        }

        JFreeChart grafico = ChartFactory.createPieChart(
                "Vendas por Mês", dataset, true, true, false);

        ChartPanel chartPanel = new ChartPanel(grafico);

        // limpa o painel e adiciona o gráfico
        panelPeriodovendas.removeAll();
        panelPeriodovendas.setLayout(new BorderLayout());
        panelPeriodovendas.add(chartPanel, BorderLayout.CENTER);
        panelPeriodovendas.validate();

        rs.close();
        stmt.close();
        coin.close();

    } catch (SQLException ex) {
        System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }
}
 
 
 
 
 
 
            



 
         
 
   
  
    

   
   
    
    
    
    
   
     



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Descontinuado;
    private javax.swing.JRadioButton ativo;
    private com.toedter.calendar.JDateChooser dateFinal;
    private com.toedter.calendar.JDateChooser dateInicio;
    private javax.swing.JRadioButton esgotado;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel label;
    private javax.swing.JPanel painelEndereço;
    private javax.swing.JPanel painelGrafico;
    private javax.swing.JPanel painelGraficoPagamento;
    private javax.swing.JPanel painelGraficoProduto;
    private javax.swing.JPanel painelGraficoVendasporCliente;
    private javax.swing.JPanel panelPeriodovendas;
    private javax.swing.JTextField pesquisaP;
    private javax.swing.JTextField pesquisarCPF;
    private javax.swing.JTextField pesquisarEstoque;
    private javax.swing.JTextField pesquisarPagamento;
    private javax.swing.JTextField pesquisarProduto;
    private javax.swing.JTable produtosmaisVendidos;
    private javax.swing.JTable produtotabela;
    private javax.swing.JTable relatorioVendasPorcliente;
    private javax.swing.JLabel resultado;
    private javax.swing.ButtonGroup statusProduto;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabelaEndereco;
    public javax.swing.JTable tabelaEstoque;
    private javax.swing.JTable tabelaPagamento;
    private javax.swing.JTable tabelaVendaPorperiodo;
    private javax.swing.JTable tabeladeletadapessoa;
    private javax.swing.JTable tabeladeletadaproduto;
    private javax.swing.JTable tabeladeletadavenda;
    // End of variables declaration//GEN-END:variables
}
