package projetoblusablusas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vitor55679526
 */
public class RegexValidarFuncionario {
    public static boolean validarNome(String nome){
        return nome.matches("^[A-ZÀ-Ù][a-zá-ú\\s[A-ZÀ-Ù]a-zá-ú]{1,20}$");
    }
    public static boolean validarSalario(String salario){
        return salario.matches("^[1-9]\\d{0,4}\\.\\d{2}$");
    }
    public static boolean validarCPF(String cpf){
        return cpf.matches("^\\d{9}\\-\\d{2}${15}");
    }
    public static boolean validarCargo(String cargo){
        return cargo.matches("^[A-Z][a-z\\sA-Za-z]{1,50}${50}");
    }
     public static boolean validarMatricula(String matricula){
        return matricula.matches("^[A-Z][a-zA-Z]+{2}\\d{1,18}${20}");
    }
     public static boolean validarEmail(String email){
         return email.matches("^[a-zA-Z0-9._%+-]+@blusablusas.com${1,30}");
     }
     
}
   
