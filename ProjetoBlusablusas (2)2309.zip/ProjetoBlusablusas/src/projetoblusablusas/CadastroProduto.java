/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author User
 */
public class CadastroProduto extends javax.swing.JInternalFrame {

   CadastroFuncionaario cf = new CadastroFuncionaario();
   String situacaoEstoque;
   String tamanhoProduto;
   
   
    public CadastroProduto() {
        initComponents();
        atualizarTabelaEstoque();
        designer();
        this.codigo.setEnabled(false);
        
        try{
            JasperReport jr = JasperCompileManager.compileReport("C:\\Users\\Vitor55679526\\Downloads\\ProjetoBlusablusas (2)\\ProjetoBlusablusas\\src\\relatorios\\relatorioestoque.jrxml");
            System.out.println("Relatório Compilado");
            
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
      
    }
public void designer(){
        this.tabelaEstoque.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEstoque.getTableHeader().setOpaque(false);
        this.tabelaEstoque.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEstoque.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEstoque.setRowHeight(25);
        
    
  }
    
    
    
    
    
    
   public void atualizarTabelaEstoque(){
          try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaestoquecritico = (DefaultTableModel) this.tabelaEstoque.getModel();
            tabelaestoquecritico.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaestoquecritico.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
   
   public void salvarProduto(){
        try {
            if(!RegexValidarProduto.ValidarProduto(produto.getText())){
                JOptionPane.showMessageDialog(null,"Produto errado!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarEstoque(estoque.getText())){
                JOptionPane.showMessageDialog(null,"Estoque errado!\nDigite números com no máximo 5 digitos");
            }else if(!RegexValidarProduto.ValidarPreco(preco.getText())){
                JOptionPane.showMessageDialog(null,"Preço errado!\nDigite  4 numeros à direita e 2 depois da vírgula ");
            }else if(!RegexValidarProduto.ValidarDescricao(descricao.getText())){
               JOptionPane.showMessageDialog(null,"Descrição errada!\nDigite apenas letras e comece com maiúscula "); 
            }else if(!RegexValidarProduto.ValidarCor(cor.getText())){
                JOptionPane.showMessageDialog(null,"cor errada!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarTecido(tecido.getText())){
                JOptionPane.showMessageDialog(null,"tecido errado!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarTipoProduto(this.categoria.getText())){
                JOptionPane.showMessageDialog(null,"Categoria/tipo de produto errado!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarURL(url.getText())){
                JOptionPane.showMessageDialog(null,"Url errado!\nDigite[http://xxxxxx.com/xxxxxxx/xxxxxx.png ou jpg ou jpeg ou gif ou bmp ou webp ou svg]");
            }else{
                
            Connection coin = conexaoBancoDeDados.conexaoBanco();
            String sql ="INSERT INTO descricao(descricao,cor,tecido,tamanho,categoria,imagem_url)VALUES(?,?,?,?,?,?)";
            PreparedStatement stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.descricao.getText());
            stmt.setString(2, this.cor.getText());
            stmt.setString(3, this.tecido.getText());
            stmt.setString(4, this.tamanhoProduto);
            stmt.setString(5, this.categoria.getText());
            stmt.setString(6,this.url.getText());
            stmt.execute();
            sql = "INSERT INTO produto(denominacao,quantidade_estoque,preco,id_descricao)VALUES(?,?,?,(SELECT id_descricao FROM descricao ORDER BY id_descricao DESC LIMIT 1));";
            stmt = coin.prepareStatement(sql);
            stmt.setString(1, this.produto.getText());
            stmt.setString(2, this.estoque.getText());
            stmt.setString(3, this.preco.getText());
            stmt.execute();
            stmt.close();
            coin.close();
            atualizarTabelaEstoque();
            limparProdutos();
            
            }
             
        } catch (SQLException ex) {
            Logger.getLogger(CadastroProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
public void editarProduto(){
       try {
           if(!RegexValidarProduto.ValidarProduto(produto.getText())){
                JOptionPane.showMessageDialog(null,"Produto errado!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarEstoque(estoque.getText())){
                JOptionPane.showMessageDialog(null,"Estoque errado!\nDigite números com no máximo 5 digitos");
            }else if(!RegexValidarProduto.ValidarPreco(preco.getText())){
                JOptionPane.showMessageDialog(null,"Preço errado!\nDigite  4 numeros à direita e 2 depois da vírgula ");
            }else if(!RegexValidarProduto.ValidarDescricao(descricao.getText())){
               JOptionPane.showMessageDialog(null,"Descrição errada!\nDigite apenas letras e comece com maiúscula "); 
            }else if(!RegexValidarProduto.ValidarCor(cor.getText())){
                JOptionPane.showMessageDialog(null,"cor errada!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarTecido(tecido.getText())){
                JOptionPane.showMessageDialog(null,"tecido errado!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarTipoProduto(this.categoria.getText())){
                JOptionPane.showMessageDialog(null,"Categoria/tipo de produto errado!\nDigite apenas letras e comece com maiúscula ");
            }else if(!RegexValidarProduto.ValidarURL(url.getText())){
                JOptionPane.showMessageDialog(null,"Url errado!\nDigite[http://xxxxxx.com/xxxxxxx/xxxxxx.png ou jpg ou jpeg ou gif ou bmp ou webp ou svg]");
            }else{
         Connection coin = conexaoBancoDeDados.conexaoBanco();
         String sql = "UPDATE descricao SET descricao = ?,cor=?,tecido=?,tamanho=?,categoria=?,imagem_url=? WHERE id_descricao=?;";
         PreparedStatement stmt = coin.prepareStatement(sql);
         stmt.setString(1, this.descricao.getText());
         stmt.setString(2, this.cor.getText());
         stmt.setString(3, this.tecido.getText());
         stmt.setString(4, this.tamanhoProduto);
         stmt.setString(5, this.categoria.getText());
         stmt.setString(6,this.url.getText());
         stmt.setString(7, this.codigo.getText());
         stmt.executeUpdate();
         sql = "UPDATE produto SET denominacao = ?,quantidade_estoque=?, preco = ?,situacao = ?  WHERE id_descricao=?;";
         stmt= coin.prepareStatement(sql);
         stmt.setString(1, this.produto.getText());
         stmt.setString(2, this.estoque.getText());
         stmt.setString(3, this.preco.getText());
         stmt.setString(4, this.situacaoEstoque);
         stmt.setString(5, this.codigo.getText());
         stmt.executeUpdate();
         stmt.close();
         coin.close();
         JOptionPane.showMessageDialog(null, "Produto alterado com sucesso");
         cf.limparCampos();   
                
         }   
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionaario.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
       
   }
   
   
    
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        grupoTamanho = new javax.swing.ButtonGroup();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        produto = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        codigo = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        estoque = new javax.swing.JTextField();
        categoria = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        preco = new javax.swing.JTextField();
        descricao = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        cor = new javax.swing.JTextField();
        tecido = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelaEstoque = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        url = new javax.swing.JTextField();
        radioAtivo = new javax.swing.JRadioButton();
        radioEsgotado = new javax.swing.JRadioButton();
        radioDescontinuado = new javax.swing.JRadioButton();
        jButton2 = new javax.swing.JButton();
        pp = new javax.swing.JRadioButton();
        p = new javax.swing.JRadioButton();
        m = new javax.swing.JRadioButton();
        g = new javax.swing.JRadioButton();
        gg = new javax.swing.JRadioButton();
        relatorioestoque = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        pesquisaP = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel3.setBackground(new java.awt.Color(102, 0, 102));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Cadastro de Produto");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(16, 16, 16))
        );

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("Tipo de Produto");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Tecido");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("Cor");

        produto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("Descrição");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Estoque");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setText("Código");

        estoque.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        categoria.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoriaActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setText("Produto");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("Tamanho");

        preco.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        descricao.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setText("Preço");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setText("Situação");

        cor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                corActionPerformed(evt);
            }
        });

        tecido.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel24.setText("Tabela de Estoque");

        jButton4.setBackground(new java.awt.Color(153, 0, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Salva");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(153, 0, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Editar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(153, 0, 153));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Excluir");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        tabelaEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Produto", "Estoque", "Preço", "SituacaoProduto", "Descricao", "Cor", "Tecido", "Tamanho", "Categoria", "URL"
            }
        ));
        tabelaEstoque.setSelectionBackground(new java.awt.Color(153, 0, 153));
        tabelaEstoque.setSelectionForeground(new java.awt.Color(255, 255, 255));
        tabelaEstoque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaEstoqueMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabelaEstoque);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Produto mais vendidos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setText("URL");

        url.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        buttonGroup1.add(radioAtivo);
        radioAtivo.setText("Ativo");
        radioAtivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioAtivoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioEsgotado);
        radioEsgotado.setText("Esgotado");
        radioEsgotado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioEsgotadoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioDescontinuado);
        radioDescontinuado.setText("Descontinuado");
        radioDescontinuado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDescontinuadoActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(153, 0, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Limpar Campos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        grupoTamanho.add(pp);
        pp.setText("PP");
        pp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ppActionPerformed(evt);
            }
        });

        grupoTamanho.add(p);
        p.setText("P");
        p.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pActionPerformed(evt);
            }
        });

        grupoTamanho.add(m);
        m.setText("M");
        m.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mActionPerformed(evt);
            }
        });

        grupoTamanho.add(g);
        g.setText("G");
        g.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gActionPerformed(evt);
            }
        });

        grupoTamanho.add(gg);
        gg.setText("GG");
        gg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ggActionPerformed(evt);
            }
        });

        relatorioestoque.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        relatorioestoque.setText("Gerar Relatório de estoque");
        relatorioestoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                relatorioestoqueActionPerformed(evt);
            }
        });

        jLabel3.setText("Pesquisar Produto : ");

        pesquisaP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisaPKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel23)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel19)
                                        .addComponent(jLabel20))
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel25))
                                .addGap(2, 2, 2))
                            .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(pp)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(m)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(gg)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(descricao, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                                        .addComponent(cor, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tecido, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(categoria, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(url, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addComponent(produto, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(radioAtivo)
                                                .addGap(18, 18, 18)
                                                .addComponent(radioEsgotado)
                                                .addGap(18, 18, 18)
                                                .addComponent(radioDescontinuado))
                                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(estoque, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)
                                                .addComponent(preco, javax.swing.GroupLayout.Alignment.LEADING))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jButton4)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton5)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton6)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 175, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1174, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(pesquisaP, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(jButton1)
                        .addGap(29, 29, 29)
                        .addComponent(relatorioestoque, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(74, 74, 74))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel21)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel14))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19))
                                .addGap(28, 28, 28)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(produto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(estoque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel18))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(preco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel23)
                                    .addComponent(radioAtivo)
                                    .addComponent(radioEsgotado)
                                    .addComponent(radioDescontinuado))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(descricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel16))
                                .addGap(18, 18, 18)
                                .addComponent(tecido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(pp)
                                    .addComponent(p)
                                    .addComponent(m)
                                    .addComponent(g)
                                    .addComponent(gg))
                                .addGap(18, 18, 18)
                                .addComponent(categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(url, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton4)
                            .addComponent(jButton5)
                            .addComponent(jButton6))
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(88, 88, 88))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(pesquisaP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1)
                            .addComponent(relatorioestoque))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(98, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jPanel2);

        getContentPane().add(jScrollPane2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        ProdutosMaisVendidos pmv = new  ProdutosMaisVendidos(null,true);
        pmv.setVisible(true);
        
        
       
       
        
        
        
       
        
        

    }//GEN-LAST:event_jButton1ActionPerformed

    private void corActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_corActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_corActionPerformed

    private void categoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categoriaActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       String mensagem = JOptionPane.showInputDialog("Autorização para cadastrar Produto");
       if(mensagem.equals("senha123")){
           salvarProduto();
       }else{
           JOptionPane.showMessageDialog(null, "Autorizacão Cancelada");
       }
        
        
        
        
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void tabelaEstoqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaEstoqueMouseClicked

      this.produto.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 1).toString());
      this.estoque.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 2).toString());
      this.preco.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 3).toString());
      this.descricao.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 5).toString());
      this.cor.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 6).toString());
      this.tecido.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 7).toString());
      tamanhoProduto = this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 8).toString();
      if(tamanhoProduto.equals("PP")){
         this.pp.setSelected(true);
      }else if(tamanhoProduto.equals("P")){
          this.p.setSelected(true);
      }else if(tamanhoProduto.equals("M")){
          this.m.setSelected(true);
      }else if(tamanhoProduto.equals("G")){
          this.g.setSelected(true);
      }else if(tamanhoProduto.equals("GG")){
          this.gg.setSelected(true);
      }
      
      //this.tamanho.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 8).toString());
      this.categoria.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 9).toString());
      this.url.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 10).toString());
      this.codigo.setText(this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 0).toString());
      situacaoEstoque = this.tabelaEstoque.getValueAt(this.tabelaEstoque.getSelectedRow(), 4).toString();
      
      if(situacaoEstoque.equals("ativo")){
          this.radioAtivo.setSelected(true);
      }else if(situacaoEstoque.equals("esgotado")){
          this.radioEsgotado.setSelected(true);
      }else if(situacaoEstoque.equals("descontinuado")){
          this.radioDescontinuado.setSelected(true);
      }
      
      
     
     
        
        
    }//GEN-LAST:event_tabelaEstoqueMouseClicked

    private void radioAtivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioAtivoActionPerformed
        situacaoEstoque = "ativo";
    }//GEN-LAST:event_radioAtivoActionPerformed

    private void radioEsgotadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioEsgotadoActionPerformed
       situacaoEstoque = "esgotado";
    }//GEN-LAST:event_radioEsgotadoActionPerformed

    private void radioDescontinuadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDescontinuadoActionPerformed
        situacaoEstoque = "descontinuado";
    }//GEN-LAST:event_radioDescontinuadoActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       editarProduto();
       atualizarTabelaEstoque();
       
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
           int resposta = JOptionPane.showConfirmDialog(null,
        "Tem certeza que deseja excluir este produto?\nEssa ação também removerá os dados importantes e sensivéis.",
       "Confirmar Exclusão",
      JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        
        if(resposta== JOptionPane.YES_NO_OPTION){
             try {
           Connection coin = conexaoBancoDeDados.conexaoBanco();
           
          String    sql="DELETE FROM historico_preco WHERE id_produto = ?";
          PreparedStatement  stmt = coin.prepareStatement(sql);
          stmt.setString(1, this.codigo.getText());
          stmt.execute();
          sql = "DELETE FROM produto WHERE id_produto=?;";
          stmt = coin.prepareStatement(sql);
          stmt.setString(1, this.codigo.getText());
          stmt.execute();
          sql = "DELETE FROM produtos_deletados WHERE id_produto = ?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigo.getText());
          stmt.execute();
           sql = "DELETE FROM descricao WHERE id_descricao = ?;";
           stmt = coin.prepareStatement(sql);
           stmt.setString(1, this.codigo.getText());
        
          
               stmt.execute();
               
              
               
               JOptionPane.showMessageDialog(null, "Produto Deletado");
               stmt.close();
               coin.close();
               atualizarTabelaEstoque();
              
               
               
          
       } catch (SQLException ex) {
           System.getLogger(CadastroFuncionaario.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
       }
            
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     this.produto.setText(null);
     this.codigo.setText(null);
     this.estoque.setText(null);
     this.preco.setText(null);
     this.descricao.setText(null);
     this.cor.setText(null);
     this.tecido.setText(null);
     this.buttonGroup1.clearSelection();
     this.grupoTamanho.clearSelection();
     this.categoria.setText(null);
     this.url.setText(null);
    
     
    }//GEN-LAST:event_jButton2ActionPerformed

    private void ppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ppActionPerformed
       tamanhoProduto = "PP";
    }//GEN-LAST:event_ppActionPerformed

    private void pActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pActionPerformed
        tamanhoProduto = "P";
    }//GEN-LAST:event_pActionPerformed

    private void mActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mActionPerformed
        tamanhoProduto = "M";
    }//GEN-LAST:event_mActionPerformed

    private void gActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gActionPerformed
        tamanhoProduto = "G";
    }//GEN-LAST:event_gActionPerformed

    private void ggActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ggActionPerformed
       tamanhoProduto = "GG";
    }//GEN-LAST:event_ggActionPerformed

    private void relatorioestoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_relatorioestoqueActionPerformed
        
        
       try {
           Connection coin = conexaoBancoDeDados.conexaoBanco();
           String caminho = "C:\\Users\\Vitor55679526\\Downloads\\ProjetoBlusablusas (2)\\ProjetoBlusablusas\\src\\relatorios\\relatorioestoque.jrxml";
           JasperReport jr =JasperCompileManager.compileReport(caminho);
           HashMap<String,Object>parametros = new HashMap<>();
           JasperPrint imprimir =JasperFillManager.fillReport(jr, parametros,coin);
           JasperViewer ver = new JasperViewer(imprimir,false);
           ver.setVisible(true);
           
       } catch (SQLException ex) {
           Logger.getLogger(CadastroProduto.class.getName()).log(Level.SEVERE, null, ex);
       } catch (JRException ex) {
               Logger.getLogger(CadastroProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
        
        
        
        
    }//GEN-LAST:event_relatorioestoqueActionPerformed

    private void pesquisaPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisaPKeyPressed
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT p.id_produto AS Codigo \n" +
",p.denominacao AS Produto ,\n" +
"p.quantidade_estoque AS QuantidadenoEstoque ,\n" +
"p.preco AS  PreÃ§o ,\n" +
"p.situacao AS SituacaoProduto,\n" +
"d.descricao AS DescriÃ§Ã£o,\n" +
"d.cor AS Cor,\n" +
"d.tecido AS Tecido,\n" +
"d.tamanho AS tamanho,\n" +
"d.categoria AS Categoria, \n" +
"d.imagem_url AS URL\n" +
"FROM produto p \n" +
"INNER JOIN descricao d ON d.id_descricao = p.id_descricao WHERE p.denominacao LIKE '%"+this.pesquisaP.getText()+"%';";
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaEstoque = (DefaultTableModel) this.tabelaEstoque.getModel();
            tabelaEstoque.setNumRows(0);
             while(rs.next()){
                  Object[] array ={rs.getString("Codigo"),rs.getString("Produto"),rs.getString("QuantidadenoEstoque"),rs.getString("PreÃ§o"),rs.getString("SituacaoProduto"),rs.getString("DescriÃ§Ã£o"),rs.getString("Cor"),rs.getString("Tecido"),rs.getString("Tamanho"),rs.getString("Categoria"),rs.getString("URL")};
                 tabelaEstoque.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
    }//GEN-LAST:event_pesquisaPKeyPressed
    
    
    public void limparProdutos(){
     this.produto.setText(null);
     this.codigo.setText(null);
     this.estoque.setText(null);
     this.preco.setText(null);
     this.descricao.setText(null);
     this.cor.setText(null);
     this.tecido.setText(null);
     this.buttonGroup1.clearSelection();
     this.grupoTamanho.clearSelection();
     this.categoria.setText(null);
     this.url.setText(null);
     
    }
  
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField categoria;
    private javax.swing.JTextField codigo;
    private javax.swing.JTextField cor;
    private javax.swing.JTextField descricao;
    private javax.swing.JTextField estoque;
    private javax.swing.JRadioButton g;
    private javax.swing.JRadioButton gg;
    private javax.swing.ButtonGroup grupoTamanho;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JRadioButton m;
    private javax.swing.JRadioButton p;
    private javax.swing.JTextField pesquisaP;
    private javax.swing.JRadioButton pp;
    private javax.swing.JTextField preco;
    private javax.swing.JTextField produto;
    private javax.swing.JRadioButton radioAtivo;
    private javax.swing.JRadioButton radioDescontinuado;
    private javax.swing.JRadioButton radioEsgotado;
    private javax.swing.JButton relatorioestoque;
    private javax.swing.JTable tabelaEstoque;
    private javax.swing.JTextField tecido;
    private javax.swing.JTextField url;
    // End of variables declaration//GEN-END:variables
}
