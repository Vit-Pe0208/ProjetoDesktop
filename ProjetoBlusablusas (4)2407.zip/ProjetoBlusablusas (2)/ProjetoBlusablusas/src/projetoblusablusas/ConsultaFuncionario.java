/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Vitor55679526
 */
public class ConsultaFuncionario extends javax.swing.JInternalFrame {

    /**
     * Creates new form ConsultaFuncionario
     */
    public ConsultaFuncionario() {
        initComponents();
        atualizartabelaAdministrador();
        designerTable();
    }
    
    public void designerTable(){
        
        this.TabelaAdministrador.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.TabelaAdministrador.getTableHeader().setOpaque(false);
        this.TabelaAdministrador.getTableHeader().setBackground(new Color(102,0,102));
        this.TabelaAdministrador.getTableHeader().setForeground(Color.WHITE);
        this.TabelaAdministrador.setRowHeight(25);
    }
    
    
    

     public void atualizartabelaAdministrador(){
        try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT \n" +
"p.nome AS Administrador,\n" +
" p.email AS EmailPessoal,\n" +
" p.cpf AS CPF,\n" +
" p.genero AS Gênero,\n" +
" p.data_nascimento AS DataNascimento,\n" +
" adm.matricula AS Matrícula,\n" +
" adm.cargo AS Cargo,\n" +
" adm.situacao AS SituaçãoADM,p.id_pessoa\n" +
" FROM administrador adm\n" +
"INNER JOIN pessoa p ON p.id_pessoa=adm.id_pessoa;";
             
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaadm = (DefaultTableModel) this.TabelaAdministrador.getModel();
            tabelaadm.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Administrador"),rs.getString("EmailPessoal")
                 ,rs.getString("CPF"),rs.getString("Gênero"),rs.getString("DataNascimento"),
                 rs.getString("Matrícula"),rs.getString("Cargo"),rs.getString("SituaçãoADM"),rs.getString("id_pessoa")};
                 tabelaadm.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaAdministrador = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        pesquisarmatricula = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Consulta Funcionário");

        jPanel1.setBackground(new java.awt.Color(102, 0, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Consulta Funcionário");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(20, 20, 20))
        );

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Tabela de Cadastro de Funcionários");

        TabelaAdministrador.setForeground(new java.awt.Color(102, 0, 102));
        TabelaAdministrador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Administrador", "Emai lPessoal", "CPF", "Gênero", "DataNascimento", "Matrícula ADM", "Cargo", "SituaçãoADM", "Código Pessoa"
            }
        ));
        TabelaAdministrador.setSelectionBackground(new java.awt.Color(153, 0, 153));
        TabelaAdministrador.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TabelaAdministrador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelaAdministradorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaAdministrador);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Pesquisar MatrículaADM :");

        pesquisarmatricula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarmatriculaKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1291, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(pesquisarmatricula, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 199, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(pesquisarmatricula, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addComponent(jLabel12)
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(233, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TabelaAdministradorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelaAdministradorMouseClicked
        
    }//GEN-LAST:event_TabelaAdministradorMouseClicked

    private void pesquisarmatriculaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarmatriculaKeyPressed
      try {
            Connection coin = conexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT \n" +
"p.nome AS Administrador,\n" +
" p.email AS EmailPessoal,\n" +
" p.cpf AS CPF,\n" +
" p.genero AS Gênero,\n" +
" p.data_nascimento AS DataNascimento,\n" +
" adm.matricula AS Matrícula,\n" +
" adm.cargo AS Cargo,\n" +
" adm.situacao AS SituaçãoADM,p.id_pessoa\n" +
" FROM administrador adm\n" +
"INNER JOIN pessoa p ON p.id_pessoa=adm.id_pessoa WHERE adm.matricula LIKE '%"+this.pesquisarmatricula.getText()+"%';";
            
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaadm = (DefaultTableModel) this.TabelaAdministrador.getModel();
            tabelaadm.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("Administrador"),rs.getString("EmailPessoal")
                 ,rs.getString("CPF"),rs.getString("Gênero"),rs.getString("DataNascimento"),
                 rs.getString("Matrícula"),rs.getString("Cargo"),rs.getString("SituaçãoADM"),rs.getString("id_pessoa")};
                 tabelaadm.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
    }//GEN-LAST:event_pesquisarmatriculaKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TabelaAdministrador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField pesquisarmatricula;
    // End of variables declaration//GEN-END:variables
}
